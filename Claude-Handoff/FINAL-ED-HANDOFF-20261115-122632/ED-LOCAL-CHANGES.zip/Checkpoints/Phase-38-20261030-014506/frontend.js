
(() => {
  const messages = document.getElementById("messages");
  const welcome = document.getElementById("welcome");
  const input = document.getElementById("input");
  const send = document.getElementById("send");
  const clear = document.getElementById("clear");
  const status = document.getElementById("status");

  const history = [];
  let busy = false;

  function removeWelcome() {
    if (welcome) {
      welcome.remove();
    }
  }

  function addMessage(role, text) {
    removeWelcome();

    const row = document.createElement("div");
    row.className = "message " + role;

    const bubble = document.createElement("div");
    bubble.className = "bubble";

    const label = document.createElement("div");
    label.className = "label";
    label.textContent = role === "user" ? "You" : "Junior";

    const body = document.createElement("div");
    body.textContent = text;

    bubble.appendChild(label);
    bubble.appendChild(body);
    row.appendChild(bubble);
    messages.appendChild(row);

    messages.scrollTop = messages.scrollHeight;
    return body;
  }

  function setBusy(value) {
    busy = value;
    send.disabled = value;
    input.disabled = value;
    status.textContent = value ? "THINKING" : "LOCAL";
  }

  function autoSize() {
    input.style.height = "auto";
    input.style.height =
      Math.min(input.scrollHeight, 150) + "px";
  }

  async function consumeJuniorStream(response, assistantBody) {
    if (!response.body || typeof response.body.getReader !== "function") {
      throw new Error("Streaming response body is unavailable.");
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder("utf-8");
    let buffer = "";
    let eventName = "message";
    let dataLines = [];
    let responseText = "";
    let completed = false;
    let memorySources = [];

    function processEvent(block) {
      const lines = block.split(/\r?\n/);
      eventName = "message";
      dataLines = [];

      for (const line of lines) {
        if (!line || line.startsWith(":")) continue;

        const colon = line.indexOf(":");
        const field = colon < 0 ? line : line.slice(0, colon);
        let value = colon < 0 ? "" : line.slice(colon + 1);
        if (value.startsWith(" ")) value = value.slice(1);

        if (field === "event") eventName = value;
        if (field === "data") dataLines.push(value);
      }

      if (!dataLines.length) return;

      const raw = dataLines.join("\n");
      let payload;

      try {
        payload = JSON.parse(raw);
      } catch {
        throw new Error("Junior sent an invalid streaming event.");
      }

      if (eventName === "token") {
        if (typeof payload.text !== "string") {
          throw new Error("Junior sent an invalid token.");
        }

        responseText += payload.text;
        assistantBody.textContent = responseText;

        const messages = document.getElementById("messages");
        if (messages) messages.scrollTop = messages.scrollHeight;

      } else if (eventName === "meta") {
        if (Array.isArray(payload.memorySources)) {
          memorySources = payload.memorySources;
        }

      } else if (eventName === "done") {
        completed = true;

      } else if (eventName === "error") {
        throw new Error(
          payload.error ||
          payload.message ||
          "Local ED streaming inference failed."
        );
      }
    }

    function consumeAvailableBlocks() {
      const blocks = buffer.split(/\r?\n\r?\n/);
      buffer = blocks.pop() || "";

      for (const block of blocks) {
        if (block.trim()) processEvent(block);
      }
    }

    try {
      while (true) {
        const result = await reader.read();

        if (result.done) break;

        buffer += decoder.decode(result.value, { stream: true });
        consumeAvailableBlocks();
      }

      buffer += decoder.decode();

      if (buffer.trim()) {
        processEvent(buffer);
        buffer = "";
      }

      if (!completed) {
        throw new Error("Junior stream ended before completion.");
      }

      if (!responseText.trim()) {
        throw new Error("Junior completed without returning a readable response.");
      }

      return {
        text: responseText,
        memorySources: memorySources
      };

    } catch (error) {
      try {
        await reader.cancel();
      } catch (_) {}
      throw error;
    }
  }

  async function askJunior() {
    const text = input.value.trim();

    if (!text || busy) {
      return;
    }

    input.value = "";
    autoSize();

    addMessage("user", text);

    const assistantBody = addMessage(
      "assistant",
      "Thinking..."
    );

    setBusy(true);

    let timeoutId;
    let requestFailed = false;

    try {
      const controller = new AbortController();
      timeoutId = setTimeout(() => controller.abort(), 180000);

      const response = await fetch("/api/ed/chat/stream", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        signal: controller.signal,
        body: JSON.stringify({
          message: text,
          history: history.slice(-20),
          mode: "direct",
          memoryContext: ""
        })
      });

      if (!response.ok) {
        let errorMessage = "Junior returned HTTP " + response.status;

        try {
          const data = await response.json();
          errorMessage =
            data.error ||
            data.message ||
            errorMessage;
        } catch (_) {}

        throw new Error(errorMessage);
      }

      const result = await consumeJuniorStream(
        response,
        assistantBody
      );

      const reply = result.text;

      history.push(
        { sender: "user", text: text },
        { sender: "assistant", text: reply }
      );

      messages.scrollTop = messages.scrollHeight;

    } catch (error) {
      requestFailed = true;
      assistantBody.textContent =
        "Junior connection error: " +
        (error && error.message ? error.message : String(error));
      status.textContent = "ERROR";

    } finally {
      if (timeoutId) clearTimeout(timeoutId);
      setBusy(false);
      if (requestFailed) status.textContent = "ERROR";
      input.focus();
    }
  }

  send.addEventListener("click", askJunior);

  input.addEventListener("keydown", event => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      askJunior();
    }
  });

  input.addEventListener("input", autoSize);

  clear.addEventListener("click", () => {
    history.length = 0;
    messages.innerHTML = `
      <section class="welcome" id="welcome">
        <h1>Junior</h1>
        <p>
          Local ED assistant. Conversation cleared.
        </p>
      </section>
    `;
    input.value = "";
    autoSize();
    status.textContent = "LOCAL";
    input.focus();
  });

  input.focus();
})();
