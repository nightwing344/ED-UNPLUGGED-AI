const fs = require("fs");
const vm = require("vm");

const source = fs.readFileSync(process.argv[2], "utf8");
const start = source.indexOf("  async function consumeJuniorStream(");
const end = source.indexOf("\n\n  async function askJunior()", start);

if (start < 0 || end < 0) {
  throw new Error("Could not extract actual frontend stream reader.");
}

const functionSource = source.slice(start, end);
const context = {
  TextDecoder,
  document: {
    getElementById() {
      return { scrollTop: 0, scrollHeight: 0 };
    }
  }
};

vm.createContext(context);
vm.runInContext(functionSource, context);

async function runReader(events, options = {}) {
  const body = { textContent: "Thinking..." };
  const bytes = Buffer.from(events, "utf8");
  const cuts = options.cuts || [1, 4, 9, 17, 25, 31, 42, 53, 67];
  const chunks = [];
  let pos = 0;

  for (const cut of cuts) {
    if (pos >= bytes.length) break;
    chunks.push(bytes.subarray(pos, Math.min(cut, bytes.length)));
    pos = Math.min(cut, bytes.length);
  }
  if (pos < bytes.length) chunks.push(bytes.subarray(pos));

  let index = 0;
  let cancelled = false;

  const response = {
    body: {
      getReader() {
        return {
          async read() {
            if (index >= chunks.length) return { done: true };
            return {
              done: false,
              value: new Uint8Array(chunks[index++])
            };
          },
          async cancel() {
            cancelled = true;
          }
        };
      }
    }
  };

  try {
    const result = await context.consumeJuniorStream(response, body);
    return { result, body, cancelled };
  } catch (error) {
    return { error, body, cancelled };
  }
}

(async () => {
  const payload =
    'event: token\r\ndata: {"text":"Junior stream: ✓ 漢字 🔬"}\r\n\r\n' +
    'event: meta\r\ndata: {"memorySources":["memory-test"]}\r\n\r\n' +
    'event: done\r\ndata: {}\r\n\r\n';

  const success = await runReader(payload);

  if (success.error) throw success.error;
  if (success.result.text !== "Junior stream: ✓ 漢字 🔬") {
    throw new Error("Unicode token content mismatch.");
  }
  if (success.body.textContent !== success.result.text) {
    throw new Error("Incremental display content mismatch.");
  }
  if (success.result.memorySources[0] !== "memory-test") {
    throw new Error("Metadata event was not captured.");
  }
  console.log("PASS: split UTF-8, token, metadata, and completion events.");

  const incomplete = await runReader(
    'event: token\ndata: {"text":"partial"}\n\n'
  );

  if (!incomplete.error ||
      !incomplete.error.message.includes("before completion")) {
    throw new Error("Incomplete stream was incorrectly accepted.");
  }
  console.log("PASS: incomplete stream rejected.");

  const failed = await runReader(
    'event: error\ndata: {"error":"mock backend failure"}\n\n'
  );

  if (!failed.error ||
      !failed.error.message.includes("mock backend failure")) {
    throw new Error("Backend error event was not propagated.");
  }
  console.log("PASS: backend error event propagated.");

  console.log("ALL STREAM READER TESTS PASSED.");
})().catch(error => {
  console.error(error);
  process.exit(1);
});
