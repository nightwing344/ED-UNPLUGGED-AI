async (req, res) => {
  const send = (event: string, payload: any) => {
    if (!res.writableEnded) {
      res.write(`event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`);
    }
  };

  const body = req.body || {};
  const message = String(body.message || '');
  if (!message.trim()) {
    return res.status(400).json({ error: 'message required' });
  }

  const history = Array.isArray(body.history) ? body.history.slice(-4) : [];
  const mode = String(body.mode || 'balanced');
  const memoryContext = String(body.memoryContext || '').slice(0, 6000);
  const isResetCommand = Boolean(body.isResetCommand);

  const formattedHistory = history
    .map((h: any) =>
      `${h.sender === 'user' ? 'USER' : 'ED'}: ${String(h.text || '').slice(0, 3000)}`
    )
    .join('\n\n');

  const userPrompt = formattedHistory
    ? `Recent Conversation:\n${formattedHistory}\n\nUSER MESSAGE:\n${message}`
    : `USER MESSAGE:\n${message}`;

  const localPrompt = memoryContext
    ? `${userPrompt}\n\nACTIVE MEMORY:\n${memoryContext}`
    : userPrompt;

  const modeDirective =
    mode === 'outside_box' ? '[MODE: OUTSIDE-THE-BOX THINKING]' :
    mode === 'teacher' ? '[MODE: TEACHING; EXPLAIN FIRST PRINCIPLES]' :
    mode === 'direct' ? '[MODE: DIRECT; MINIMIZE PREFACE]' :
    '[MODE: BALANCED]';

  const responseRules = [
    '[ED CHAT RESPONSE RULES]',
    '- Answer the current user request directly.',
    '- Follow explicit output-format and length constraints exactly.',
    '- For simple questions, give the answer without a project plan or code.',
    '- Do not introduce ED architecture or retrieval unless the user asks.',
    '- Use memory only when relevant; do not let it replace the current question.',
    '- Ask a clarifying question only when essential information is missing.'
  ].join('\n');

  const resetDirective = isResetCommand
    ? '[CONVERSATION RESET: refocus on the current request.]'
    : '';

  const compactPrompt = [
    responseRules, modeDirective, resetDirective, localPrompt
  ].filter(Boolean).join('\n\n');

  const root = path.resolve(process.cwd(), '../..');
  const helper = path.join(root, 'Runtime', 'ed-ask-stream-v1.sh');

  res.status(200);
  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  let diagnostic = '';
  let pending = '';
  const stdoutDecoder = new StringDecoder('utf8');
  const stderrDecoder = new StringDecoder('utf8');
  let streamError = '';
  let backendDone = false;
  let closed = false;

  const child = spawn(helper, [compactPrompt], {
    cwd: root,
    env: {
      ...process.env,
      ED_CORE: root,
      ...(message ? { ED_RETRIEVAL_QUERY: message } : {})
    },
    stdio: ['ignore', 'pipe', 'pipe']
  });

  const timeoutMs = Math.max(
    1000,
    Number(process.env.ED_RUNTIME_TIMEOUT_MS) || 180000
  );

  const timer = setTimeout(() => {
    streamError = 'Local ED runtime timed out.';
    child.kill('SIGTERM');
  }, timeoutMs);

  const consumeLine = (line: string) => {
    if (!line.startsWith('ED_STREAM:')) {
      diagnostic = (diagnostic + line + '\n').slice(-30000);
      return;
    }

    try {
      const item = JSON.parse(line.slice('ED_STREAM:'.length));

      if (item.type === 'token' && typeof item.text === 'string') {
        send('token', { text: item.text });
      } else if (item.type === 'backend_done') {
        backendDone = true;
      } else if (item.type === 'error') {
        streamError = String(item.message || 'Local inference failed.');
      }
    } catch {
      streamError = 'Invalid streaming protocol from local runtime.';
    }
  };

  child.stdout.on('data', (chunk: Buffer) => {
    const decoded = stdoutDecoder.write(chunk);
    pending += decoded;
    const lines = pending.split(/\r?\n/);
    pending = lines.pop() || '';
    for (const line of lines) consumeLine(line);
  });

  child.stderr.on('data', (chunk: Buffer) => {
    const decodedStderr = stderrDecoder.write(chunk);
    diagnostic = (diagnostic + decodedStderr).slice(-30000);
  });

  child.on('error', (error) => {
    streamError = error.message;
  });

  res.on('close', () => {
    if (!res.writableEnded) {
      closed = true;
      clearTimeout(timer);
      child.kill('SIGTERM');
    }
  });

  child.on('close', (code) => {
    clearTimeout(timer);
    pending += stdoutDecoder.end();
    diagnostic = (diagnostic + stderrDecoder.end()).slice(-30000);
    if (pending) consumeLine(pending);

    if (closed || res.writableEnded) return;

    const sourceBlock = diagnostic.match(
      /MEMORY SOURCES:\s*([\s\S]*?)\s*ED RESPONSE:/
    );

    const memorySources = (sourceBlock?.[1] || '')
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line.startsWith('- '))
      .map((line) => line.slice(2).trim())
      .filter((line) => line && line !== 'none');

    send('meta', { memorySources });

    if (code !== 0 || !backendDone || streamError) {
      send('error', {
        error: streamError || `Local ED stream failed (exit ${code}).`,
        localOnly: true
      });
    } else {
      send('done', { localOnly: true });
    }

    res.end();
  });
};