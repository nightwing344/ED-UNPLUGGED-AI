const fs = require("fs");
const path = require("path");
const vm = require("vm");
const { EventEmitter } = require("events");
const { createRequire } = require("module");
const { StringDecoder } = require("node:string_decoder");

const ROOT = process.env.ED_TEST_ROOT;
const WEB = path.join(ROOT, "Interface", "Web");
const ROUTE_FILE = process.env.ED_TEST_ROUTE;

process.chdir(WEB);

const projectRequire = createRequire(path.join(WEB, "package.json"));
const express = projectRequire("express");
const ts = projectRequire("typescript");

const routeSource = fs.readFileSync(ROUTE_FILE, "utf8").trim();
const wrapped = `module.exports = (${routeSource.replace(/;$/, "")});`;

const transpiled = ts.transpileModule(wrapped, {
  compilerOptions: {
    target: ts.ScriptTarget.ES2020,
    module: ts.ModuleKind.CommonJS
  },
  reportDiagnostics: true
});

const errors = (transpiled.diagnostics || []).filter(
  d => d.category === ts.DiagnosticCategory.Error
);

if (errors.length) {
  throw new Error(
    "TypeScript transpilation failed: " +
    errors.map(d => ts.flattenDiagnosticMessageText(d.messageText, "\n")).join("; ")
  );
}

let activeScenario = "success";
const spawned = [];

class MockChild extends EventEmitter {
  constructor() {
    super();
    this.stdout = new EventEmitter();
    this.stderr = new EventEmitter();
    this.killCalls = [];
    this.closed = false;
  }

  kill(signal) {
    this.killCalls.push(signal);

    if (!this.closed) {
      this.closed = true;
      this.emit("close", 143);
    }

    return true;
  }
}

function mockSpawn(helper, args, options) {
  const child = new MockChild();

  spawned.push({
    scenario: activeScenario,
    helper,
    args,
    options,
    child
  });

  const scenario = activeScenario;

  if (scenario === "success") {
    setTimeout(() => {
      child.stderr.emit(
        "data",
        Buffer.from("MEMORY SOURCES:\n- phase42-mock-memory\nED RESPONSE:\n")
      );

      const tokenLine =
        'ED_STREAM:{"type":"token","text":"Unicode verified: 漢字 🔬 ✓"}\n';

      const bytes = Buffer.from(tokenLine, "utf8");
      const splitAt = bytes.indexOf(Buffer.from("漢", "utf8")) + 1;

      // Deliberately split inside a multibyte UTF-8 character.
      child.stdout.emit("data", bytes.subarray(0, splitAt));
      child.stdout.emit("data", bytes.subarray(splitAt));

      child.stdout.emit(
        "data",
        Buffer.from(
          'ED_STREAM:{"type":"token","text":" Second token."}\n' +
          'ED_STREAM:{"type":"backend_done"}\n'
        )
      );

      child.closed = true;
      child.emit("close", 0);
    }, 20);
  }

  if (scenario === "error") {
    setTimeout(() => {
      child.stdout.emit(
        "data",
        Buffer.from(
          'ED_STREAM:{"type":"error","message":"mock inference failure"}\n'
        )
      );

      child.closed = true;
      child.emit("close", 1);
    }, 20);
  }

  if (scenario === "timeout") {
    // Intentionally remain open until the actual route timeout calls kill().
  }

  if (scenario === "disconnect") {
    setTimeout(() => {
      child.stdout.emit(
        "data",
        Buffer.from(
          'ED_STREAM:{"type":"token","text":"Disconnect test token"}\n'
        )
      );
    }, 20);
  }

  return child;
}

const moduleObject = { exports: {} };

vm.runInNewContext(
  transpiled.outputText,
  {
    module: moduleObject,
    exports: moduleObject.exports,
    require,
    process,
    path,
    spawn: mockSpawn,
    StringDecoder,
    Buffer,
    setTimeout,
    clearTimeout,
    console
  },
  { filename: "phase42-transpiled-route.js" }
);

const actualHandler = moduleObject.exports;

if (typeof actualHandler !== "function") {
  throw new Error("Extracted route did not evaluate to a handler function.");
}

const app = express();
app.use(express.json());
app.post("/api/ed/chat/stream", actualHandler);

const server = app.listen(0, "127.0.0.1");

function assert(condition, message) {
  if (!condition) throw new Error(message);
  console.log("PASS:", message);
}

function parseEvents(text) {
  return [...text.matchAll(/event: ([^\r\n]+)\r?\ndata: ([^\r\n]*)\r?\n\r?\n/g)]
    .map(match => ({
      event: match[1],
      data: JSON.parse(match[2])
    }));
}

async function waitFor(predicate, timeoutMs = 1800) {
  const start = Date.now();

  while (Date.now() - start < timeoutMs) {
    if (predicate()) return true;
    await new Promise(resolve => setTimeout(resolve, 20));
  }

  return predicate();
}

async function requestJson(port, body, signal) {
  return fetch(`http://127.0.0.1:${port}/api/ed/chat/stream`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal
  });
}

async function main() {
  // Wait for Express to finish binding its isolated test listener.
  await new Promise((resolve, reject) => {
    if (server.listening) return resolve();
    server.once("listening", resolve);
    server.once("error", reject);
  });

  const address = server.address();
  if (!address || typeof address === "string") {
    throw new Error("Isolated Express listener did not provide a TCP port.");
  }
  const port = address.port;
  const originalTimeout = process.env.ED_RUNTIME_TIMEOUT_MS;

  try {
    console.log("\nTEST 1: Empty message rejection");
    activeScenario = "success";

    const empty = await requestJson(port, { message: "   " });
    const emptyBody = await empty.json();

    assert(empty.status === 400, "Empty message returns HTTP 400");
    assert(emptyBody.error === "message required", "Empty message has expected error");
    assert(spawned.length === 0, "Empty message does not launch local helper");

    console.log("\nTEST 2: Actual route success and Unicode streaming");
    activeScenario = "success";

    const success = await requestJson(port, {
      message: "Phase 42 test request",
      mode: "direct",
      history: [{ sender: "user", text: "Earlier context" }],
      memoryContext: "Test memory context"
    });

    const successText = await success.text();
    const successEvents = parseEvents(successText);
    const successNames = successEvents.map(x => x.event);
    const successTokens = successEvents
      .filter(x => x.event === "token")
      .map(x => x.data.text)
      .join("");

    assert(success.status === 200, "Success returns HTTP 200");
    assert(
      successNames.join(",") === "token,token,meta,done",
      "Success event order is token, token, meta, done"
    );
    assert(
      successTokens === "Unicode verified: 漢字 🔬 ✓ Second token.",
      "Unicode survives a split UTF-8 character boundary"
    );
    assert(
      successEvents.some(x =>
        x.event === "meta" &&
        x.data.memorySources.includes("phase42-mock-memory")
      ),
      "Memory source metadata is extracted and emitted"
    );
    assert(
      successEvents.at(-1).data.localOnly === true,
      "Successful completion explicitly reports localOnly=true"
    );

    const successSpawn = spawned.find(x => x.scenario === "success");

    assert(
      successSpawn.helper.endsWith("/Runtime/ed-ask-stream-v1.sh"),
      "Actual route targets the intended local streaming helper"
    );
    assert(
      successSpawn.args[0].includes("Phase 42 test request") &&
      successSpawn.args[0].includes("[MODE: DIRECT]") &&
      successSpawn.args[0].includes("ACTIVE MEMORY"),
      "Route builds prompt from message, mode, and memory context"
    );
    assert(
      successSpawn.options.env.ED_RETRIEVAL_QUERY === "Phase 42 test request",
      "Route passes the retrieval query to the local helper"
    );

    console.log("\nTEST 3: Local inference error");
    activeScenario = "error";

    const errorResponse = await requestJson(port, {
      message: "Trigger mock local error"
    });

    const errorText = await errorResponse.text();
    const errorEvents = parseEvents(errorText);
    const errorNames = errorEvents.map(x => x.event);

    assert(errorResponse.status === 200, "SSE transport opens before inference error");
    assert(
      errorNames.join(",") === "meta,error",
      "Inference failure emits meta then error, never done"
    );
    assert(
      errorEvents.at(-1).data.localOnly === true,
      "Failure explicitly identifies local-only execution"
    );
    assert(
      errorEvents.at(-1).data.error.includes("mock inference failure"),
      "Original local inference error is preserved"
    );

    console.log("\nTEST 4: Route timeout");
    activeScenario = "timeout";
    process.env.ED_RUNTIME_TIMEOUT_MS = "1000";

    const timeoutResponse = await requestJson(port, {
      message: "Trigger timeout test"
    });

    const timeoutText = await timeoutResponse.text();
    const timeoutEvents = parseEvents(timeoutText);
    const timeoutSpawn = spawned.find(x => x.scenario === "timeout");

    assert(
      timeoutEvents.some(x =>
        x.event === "error" &&
        x.data.error.includes("timed out")
      ),
      "Timeout emits an explicit SSE error"
    );
    assert(
      timeoutSpawn && timeoutSpawn.child.killCalls.includes("SIGTERM"),
      "Timeout terminates the local child process"
    );
    assert(
      !timeoutEvents.some(x => x.event === "done"),
      "Timeout cannot be reported as successful completion"
    );

    if (originalTimeout === undefined) {
      delete process.env.ED_RUNTIME_TIMEOUT_MS;
    } else {
      process.env.ED_RUNTIME_TIMEOUT_MS = originalTimeout;
    }

    console.log("\nTEST 5: Client disconnect cleanup");
    activeScenario = "disconnect";

    const controller = new AbortController();
    const disconnectResponse = await requestJson(
      port,
      { message: "Trigger client disconnect" },
      controller.signal
    );

    const reader = disconnectResponse.body.getReader();
    let firstChunk = "";

    while (!firstChunk.includes("event: token")) {
      const part = await reader.read();
      if (part.done) break;
      firstChunk += new TextDecoder().decode(part.value, { stream: true });
    }

    assert(
      firstChunk.includes("event: token"),
      "Client receives first token before disconnect"
    );

    const disconnectSpawn = spawned.find(x => x.scenario === "disconnect");
    controller.abort();

    const killed = await waitFor(
      () => disconnectSpawn &&
        disconnectSpawn.child.killCalls.includes("SIGTERM")
    );

    assert(killed, "Client disconnect kills the local child process");

    console.log("\nTEST 6: Local-only execution boundary");
    assert(
      spawned.every(x =>
        x.helper.endsWith("/Runtime/ed-ask-stream-v1.sh")
      ),
      "Every spawned process is the local ED streaming helper"
    );
    assert(
      spawned.length === 4,
      "Only four valid-message requests launched a helper"
    );

    console.log("\nPHASE 42 RESULT: PASS");
  } finally {
    if (originalTimeout === undefined) {
      delete process.env.ED_RUNTIME_TIMEOUT_MS;
    } else {
      process.env.ED_RUNTIME_TIMEOUT_MS = originalTimeout;
    }

    server.close();
  }
}

main().catch(error => {
  console.error("\nPHASE 42 RESULT: FAIL");
  console.error(error && error.stack ? error.stack : error);
  process.exitCode = 1;
  server.close();
});
