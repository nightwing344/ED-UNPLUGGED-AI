import json
import os
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path

request_file = Path(sys.argv[1])
out_dir = Path(sys.argv[2])
api = "http://127.0.0.1:11434"
model_name = "llama3.2:3b"

def save(name, content):
    (out_dir / name).write_text(content, encoding="utf-8")

def api_json(url, payload=None, timeout=15):
    data = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(
        url, data=data,
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))

# Confirm Ollama is already running. Never start it here.
try:
    tags = api_json(api + "/api/tags")
except Exception as exc:
    print("FAIL: Existing Ollama API is not reachable:", repr(exc))
    sys.exit(2)

models = [
    item.get("name", "")
    for item in tags.get("models", [])
]
matched = next(
    (name for name in models
     if name == model_name or name.startswith(model_name + ":")),
    None
)
if not matched:
    print("FAIL: Expected local model not found:", model_name)
    print("Available models:", models)
    sys.exit(3)

raw = json.loads(request_file.read_text(encoding="utf-8"))
if not isinstance(raw, dict):
    print("FAIL: Original request is not a JSON object")
    sys.exit(4)

request_text = None
for key in ("message", "prompt", "input"):
    value = raw.get(key)
    if isinstance(value, str) and value.strip():
        request_text = value.strip()
        break

if not request_text:
    print("FAIL: No usable message/prompt/input field in request.json")
    sys.exit(5)

save("original-request.txt", request_text)

identity_a = """You are ED (ED Unplugged AI), an operating intelligence assistant.

You are not merely a command dispatcher.

Your job is to understand the user's request, reason about it, use relevant supplied memory when useful, and give a direct useful response.

Core rules:
- Never claim an action occurred unless it actually occurred.
- Never claim a subsystem is working merely because its file exists.
- Distinguish real execution from planned capability.
- User retains authority over destructive or persistent changes.
- Do not silently write memory.
- Do not invent memories.
- If supplied memory is irrelevant, ignore it.
- Be concise but useful.
- Respond to the user's actual request rather than describing the architecture."""

identity_b = """You are ED (ED Unplugged AI), an operating intelligence assistant.

Understand the user's request, reason carefully, and provide a direct, useful response.

Core rules:
- Never claim an action occurred unless it actually occurred.
- Never claim a subsystem is working merely because its file exists.
- Distinguish real execution from planned capability.
- User retains authority over destructive or persistent changes.
- Do not silently write memory.
- Do not invent memories.
- Ignore irrelevant context.
- Follow the user's explicitly requested scope, structure, and length.
- Be concise when the request does not specify depth.
- When the user requests long-form work, provide the requested depth rather than refusing or substituting an offer.
- Respond to the actual request."""

def make_prompt(identity):
    return (
        identity
        + "\n\nPERSISTENT MEMORY CONTEXT:\n\n"
        + "\n\nUSER REQUEST:\n"
        + request_text
        + "\n\nED RESPONSE:"
    )

def run_test(label, identity, num_predict):
    prompt = make_prompt(identity)
    save(label + "-prompt.txt", prompt)

    payload = {
        "model": matched,
        "prompt": prompt,
        "stream": True,
        "options": {
            "num_predict": num_predict
        }
    }

    req = urllib.request.Request(
        api + "/api/generate",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"}
    )

    start = time.monotonic()
    pieces = []
    final_obj = {}
    error = None

    try:
        with urllib.request.urlopen(req, timeout=300) as response:
            if response.status != 200:
                raise RuntimeError("HTTP status " + str(response.status))
            for raw_line in response:
                line = raw_line.decode("utf-8", errors="replace").strip()
                if not line:
                    continue
                obj = json.loads(line)
                if obj.get("response"):
                    pieces.append(obj["response"])
                if obj.get("error"):
                    error = obj["error"]
                if obj.get("done"):
                    final_obj = obj
    except Exception as exc:
        error = repr(exc)

    elapsed = round(time.monotonic() - start, 2)
    text = "".join(pieces)
    save(label + "-response.txt", text)
    save(
        label + "-metadata.json",
        json.dumps({
            "model": matched,
            "num_predict": num_predict,
            "elapsed_seconds": elapsed,
            "characters": len(text),
            "words": len(text.split()),
            "done": bool(final_obj.get("done")),
            "done_reason": final_obj.get("done_reason"),
            "eval_count": final_obj.get("eval_count"),
            "prompt_eval_count": final_obj.get("prompt_eval_count"),
            "error": error
        }, indent=2)
    )

    return {
        "label": label,
        "num_predict": num_predict,
        "elapsed": elapsed,
        "characters": len(text),
        "words": len(text.split()),
        "done": bool(final_obj.get("done")),
        "done_reason": final_obj.get("done_reason", "unknown"),
        "eval_count": final_obj.get("eval_count", "unknown"),
        "error": error,
        "response": text
    }

print("[PASS] Ollama API already running at 127.0.0.1:11434")
print("[PASS] Local model available:", matched)
print("[PASS] Original request loaded:", len(request_text), "characters")
print("[INFO] Test A: existing identity, output limit 512")
a = run_test("test-a-existing", identity_a, 512)
print("[INFO] Test B: length-aware identity, output limit 2048")
b = run_test("test-b-length-aware", identity_b, 2048)

def summarize(item):
    return (
        f"{item['label']}: words={item['words']}, "
        f"characters={item['characters']}, "
        f"elapsed={item['elapsed']}s, done={item['done']}, "
        f"reason={item['done_reason']}, eval_count={item['eval_count']}, "
        f"error={item['error']}"
    )

print("\n=== TEST RESULTS ===")
print(summarize(a))
print(summarize(b))

print("\n=== TEST A RESPONSE ===\n")
print(a["response"])
print("\n=== TEST B RESPONSE ===\n")
print(b["response"])

save("comparison.txt", summarize(a) + "\n" + summarize(b) + "\n")

# Both tests must have completed without transport/model errors.
if a["error"] or b["error"] or not a["done"] or not b["done"]:
    result = "FAILED"
elif b["words"] > a["words"]:
    result = "PASSED: B produced a longer response than A"
else:
    result = "PASSED WITH FINDING: B did not produce a longer response"

save("test-result.txt", result)
print("\n" + result)
