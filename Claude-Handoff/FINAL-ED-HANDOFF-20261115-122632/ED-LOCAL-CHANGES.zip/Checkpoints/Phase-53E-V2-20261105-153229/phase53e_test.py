import ast
import json
import sys
import time
import urllib.request
from pathlib import Path

source = Path(__file__).read_text(encoding="utf-8")
ast.parse(source)
print("[MOCK PASS] Python source parses", flush=True)

# Simulate SSE event parsing without network access.
fixture = [
    {"response": "ED", "done": False},
    {"response": " works", "done": False},
    {"response": "", "done": True, "done_reason": "stop"}
]

chunks = []
done = False
for event in fixture:
    if event.get("response"):
        chunks.append(event["response"])
    if event.get("done"):
        done = True

mock_text = "".join(chunks)
assert mock_text == "ED works"
assert done
print("[MOCK PASS] Streaming token accumulation", flush=True)
print("[MOCK PASS] Completion event detection", flush=True)

if len(sys.argv) > 1 and sys.argv[1] == "--mock-only":
    print("[MOCK PASS] No network request performed", flush=True)
    sys.exit(0)

request_file = Path(sys.argv[1])
out = Path(sys.argv[2])
api = "http://127.0.0.1:11434"
wanted = "llama3.2:3b"

def say(s):
    print(s, flush=True)

def save(name, value):
    (out / name).write_text(value, encoding="utf-8")

raw = json.loads(request_file.read_text(encoding="utf-8"))
request_text = next(
    (raw.get(k).strip() for k in ("message", "prompt", "input")
     if isinstance(raw.get(k), str) and raw.get(k).strip()),
    None
)
if not request_text:
    raise RuntimeError("No usable request text found")

tags_req = urllib.request.Request(api + "/api/tags")
with urllib.request.urlopen(tags_req, timeout=10) as r:
    tags = json.loads(r.read().decode())

models = [m.get("name", "") for m in tags.get("models", [])]
model = next((m for m in models if m == wanted or
              m.startswith(wanted + ":")), None)
if not model:
    raise RuntimeError("Required local model not found")

identity_a = """You are ED (ED Unplugged AI), an operating intelligence assistant.
Understand the user's request and give a direct, useful response.
Never claim actions that did not occur. Do not invent memories.
Ignore irrelevant context. Be concise but useful.
Respond to the user's actual request."""

identity_b = """You are ED (ED Unplugged AI), an operating intelligence assistant.
Understand the user's request and give a direct, useful response.
Never claim actions that did not occur. Do not invent memories.
Ignore irrelevant context. Follow the user's explicitly requested scope,
structure, and length. Be concise when no length is specified.
For long-form requests, provide the requested depth.
Respond to the user's actual request."""

def run(label, identity, limit):
    prompt = identity + (
        "\n\nPERSISTENT MEMORY CONTEXT:\n"
        "\n\nUSER REQUEST:\n" + request_text +
        "\n\nED RESPONSE:"
    )
    save(label + "-prompt.txt", prompt)

    payload = {
        "model": model,
        "prompt": prompt,
        "stream": True,
        "options": {"num_predict": limit}
    }

    req = urllib.request.Request(
        api + "/api/generate",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"}
    )

    say(f"[START] {label}; num_predict={limit}")
    started = time.monotonic()
    pieces = []
    final = {}
    last = started
    error = None

    try:
        with urllib.request.urlopen(req, timeout=300) as response:
            say("[HTTP] " + str(response.status))
            for line in response:
                line = line.decode("utf-8", errors="replace").strip()
                if not line:
                    continue
                event = json.loads(line)
                if event.get("response"):
                    pieces.append(event["response"])
                if event.get("error"):
                    error = event["error"]
                if event.get("done"):
                    final = event

                now = time.monotonic()
                if now - last >= 3:
                    say(
                        f"[LIVE] {label}: chunks={len(pieces)} "
                        f"words={len(''.join(pieces).split())} "
                        f"elapsed={now-started:.0f}s"
                    )
                    last = now
    except Exception as exc:
        error = repr(exc)

    elapsed = round(time.monotonic() - started, 2)
    answer = "".join(pieces)
    words = len(answer.split())
    save(label + "-response.txt", answer)

    metadata = {
        "model": model,
        "num_predict": limit,
        "elapsed_seconds": elapsed,
        "chunks": len(pieces),
        "characters": len(answer),
        "words": words,
        "done": bool(final.get("done")),
        "done_reason": final.get("done_reason"),
        "eval_count": final.get("eval_count"),
        "prompt_eval_count": final.get("prompt_eval_count"),
        "error": error
    }
    save(label + "-metadata.json", json.dumps(metadata, indent=2))
    say("[RESULT] " + label + ": " + json.dumps(metadata))
    return metadata

say("[MODEL] " + model)
say("[REQUEST] " + str(len(request_text)) + " characters")

a = run("test-a-existing", identity_a, 512)
b = run("test-b-length-aware", identity_b, 2048)

save(
    "comparison.txt",
    "TEST A\n" + json.dumps(a, indent=2) +
    "\n\nTEST B\n" + json.dumps(b, indent=2)
)

if a["error"] or b["error"] or not a["done"] or not b["done"]:
    result = "FAILED: inference or completion error"
elif b["words"] > a["words"]:
    result = "PASSED: Test B produced a longer response"
else:
    result = "PASSED WITH FINDING: Test B did not produce a longer response"

save("test-result.txt", result)
say("[COMPLETE] " + result)
