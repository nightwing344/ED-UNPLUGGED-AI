#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

ROOT="$HOME/ED-GITHUB-COMPARE"
CP="$ROOT/Checkpoints"
STAMP="$(date +%Y%m%d-%H%M%S)"
OUT="$CP/Phase-53E-CONTROLLED-$STAMP"
mkdir -p "$OUT"

REPORT="$OUT/final-report.txt"
LOG="$OUT/diagnostic.log"
PY="$OUT/phase53e_test.py"

exec > >(tee -a "$LOG") 2>&1

echo "ED PHASE 53E: CONTROLLED LOCAL MODEL TEST"
echo "Timestamp: $STAMP"
echo "Checkpoint: $OUT"

fail() { echo "[FAIL] $*"; exit 1; }

# Prevent overlapping runs of this diagnostic.
if pgrep -af 'phase53e_test.py' | grep -v "$$" | grep -q .; then
    fail "Another Phase 53E Python test appears to be running. No new test started."
fi

[[ -d "$ROOT" ]] || fail "Repository missing"
[[ -d "$CP" ]] || fail "Checkpoint directory missing"
command -v python >/dev/null || fail "Python unavailable"
command -v termux-clipboard-set >/dev/null || echo "[WARN] Clipboard SET command unavailable"
command -v termux-clipboard-get >/dev/null || echo "[WARN] Clipboard GET command unavailable"

SOURCE_DIR="$(find "$CP" -maxdepth 1 -type d \
    -name 'Phase-53-COMBINED-*' -print | sort | tail -n 1)"

[[ -n "$SOURCE_DIR" ]] || fail "Phase 53 combined checkpoint not found"
REQUEST="$SOURCE_DIR/request.json"
[[ -s "$REQUEST" ]] || fail "Original request file missing"

cat > "$PY" <<'PYTHON'
import json, sys, time, urllib.request
from pathlib import Path

request_file = Path(sys.argv[1])
out = Path(sys.argv[2])
api = "http://127.0.0.1:11434"
model_wanted = "llama3.2:3b"

def say(message):
    print(message, flush=True)

def save(name, value):
    (out / name).write_text(value, encoding="utf-8")

def get_json(url, payload=None, timeout=15):
    data = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(
        url, data=data,
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())

say("[1/5] Checking existing local Ollama API...")
try:
    tags = get_json(api + "/api/tags")
except Exception as e:
    say("FAIL: Ollama is not already reachable. Not starting it.")
    say(repr(e))
    sys.exit(2)

models = [m.get("name", "") for m in tags.get("models", [])]
model = next((m for m in models if m == model_wanted or
              m.startswith(model_wanted + ":")), None)
if not model:
    say("FAIL: Expected local model not installed: " + model_wanted)
    say("Available models: " + repr(models))
    sys.exit(3)

say("[PASS] Local model: " + model)

say("[2/5] Loading original Phase 53 request...")
raw = json.loads(request_file.read_text(encoding="utf-8"))
request_text = next(
    (raw.get(k).strip() for k in ("message", "prompt", "input")
     if isinstance(raw.get(k), str) and raw.get(k).strip()),
    None
)
if not request_text:
    say("FAIL: No usable request text found.")
    sys.exit(4)

save("original-request.txt", request_text)
say("[PASS] Request loaded: " + str(len(request_text)) + " characters")

identity_a = """You are ED (ED Unplugged AI), an operating intelligence assistant.
Your job is to understand the user's request, reason about it, and give a direct useful response.
Core rules:
- Never claim an action occurred unless it actually occurred.
- Never claim a subsystem works merely because its file exists.
- Distinguish execution from planned capability.
- User retains authority over destructive or persistent changes.
- Do not silently write memory or invent memories.
- Ignore irrelevant context.
- Be concise but useful.
- Respond to the user's actual request."""

identity_b = """You are ED (ED Unplugged AI), an operating intelligence assistant.
Understand the user's request, reason carefully, and provide a direct useful response.
Core rules:
- Never claim an action occurred unless it actually occurred.
- Never claim a subsystem works merely because its file exists.
- Distinguish execution from planned capability.
- User retains authority over destructive or persistent changes.
- Do not silently write memory or invent memories.
- Ignore irrelevant context.
- Follow the user's explicitly requested scope, structure, and length.
- Be concise when no length is specified.
- For long-form requests, provide the requested depth rather than refusing or substituting an offer.
- Respond to the actual request."""

def make_prompt(identity):
    return identity + (
        "\n\nPERSISTENT MEMORY CONTEXT:\n\n"
        "\n\nUSER REQUEST:\n" + request_text +
        "\n\nED RESPONSE:"
    )

def run(label, identity, limit):
    prompt = make_prompt(identity)
    save(label + "-prompt.txt", prompt)
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": True,
        "options": {"num_predict": limit}
    }
    req = urllib.request.Request(
        api + "/api/generate",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"}
    )

    say(f"\n[3/5] {label}: starting inference, num_predict={limit}")
    start = time.monotonic()
    pieces = []
    final = {}
    error = None
    last_progress = start

    try:
        with urllib.request.urlopen(req, timeout=300) as response:
            say(f"[HTTP] {response.status}")
            for raw_line in response:
                line = raw_line.decode("utf-8", errors="replace").strip()
                if not line:
                    continue
                obj = json.loads(line)
                piece = obj.get("response", "")
                if piece:
                    pieces.append(piece)
                    now = time.monotonic()
                    if now - last_progress >= 3:
                        say(
                            f"[LIVE] {label}: "
                            f"{len(pieces)} chunks, "
                            f"{len(''.join(pieces).split())} words, "
                            f"{now-start:.0f}s"
                        )
                        last_progress = now
                if obj.get("error"):
                    error = str(obj["error"])
                if obj.get("done"):
                    final = obj
    except Exception as e:
        error = repr(e)

    elapsed = round(time.monotonic() - start, 2)
    answer = "".join(pieces)
    words = len(answer.split())
    save(label + "-response.txt", answer)

    metadata = {
        "model": model,
        "num_predict": limit,
        "elapsed_seconds": elapsed,
        "chunks": len(pieces),
        "characters": len(answer),
        "words": words,
        "done": bool(final.get("done")),
        "done_reason": final.get("done_reason"),
        "eval_count": final.get("eval_count"),
        "prompt_eval_count": final.get("prompt_eval_count"),
        "error": error
    }
    save(label + "-metadata.json", json.dumps(metadata, indent=2))
    say(
        f"[RESULT] {label}: {words} words, {len(answer)} characters, "
        f"{elapsed}s, done={metadata['done']}, "
        f"reason={metadata['done_reason']}, error={error}"
    )
    return metadata

say("[4/5] Running controlled comparison. No live ED components involved.")
a = run("test-a-existing", identity_a, 512)
b = run("test-b-length-aware", identity_b, 2048)

summary = (
    "TEST A: " + json.dumps(a, sort_keys=True) + "\n"
    "TEST B: " + json.dumps(b, sort_keys=True) + "\n"
)
save("comparison.txt", summary)

if a["error"] or b["error"] or not a["done"] or not b["done"]:
    result = "FAILED: one or both inference tests did not complete cleanly"
elif b["words"] > a["words"]:
    result = "PASSED: length-aware test produced more words"
else:
    result = "PASSED WITH FINDING: length-aware test did not produce more words"

save("test-result.txt", result)
say("\n[5/5] Comparison complete.")
say(result)
PYTHON

echo "[CHECK] Bash syntax..."
bash -n "$0" || fail "Bash syntax failed"
echo "[PASS] Bash syntax"

echo "[CHECK] Python syntax..."
python -m py_compile "$PY" || fail "Python syntax failed"
echo "[PASS] Python syntax"

echo "[INFO] Starting unbuffered Python. Live progress enabled."
if python -u "$PY" "$REQUEST" "$OUT"; then
    RESULT="$(cat "$OUT/test-result.txt")"
else
    RESULT="FAILED: diagnostic process returned an error"
fi

# Create the final report once, then copy and verify it.
{
    echo "ED UNPLUGGED AI - PHASE 53E FINAL REPORT"
    echo "Timestamp: $STAMP"
    echo "Result: $RESULT"
    echo
    echo "Original request: $REQUEST"
    echo "Prompt: isolated reconstruction, not captured live effective prompt"
    echo "Endpoint: 127.0.0.1:11434"
    echo "Model: llama3.2:3b"
    echo
    echo "=== COMPARISON ==="
    cat "$OUT/comparison.txt" 2>/dev/null || echo "Comparison unavailable"
    echo
    echo "Source edits: NONE"
    echo "Build: NOT RUN"
    echo "Live ED server requests: NONE"
    echo "Live helper execution: NONE"
    echo "Service restart: NONE"
    echo "Git mutation: NONE"
    echo
    echo "Checkpoint: $OUT"
    echo "Diagnostic log: $LOG"
} > "$REPORT"

echo
echo "=== FINAL REPORT ==="
cat "$REPORT"

CLIP_SET="NOT AVAILABLE"
CLIP_VERIFY="NOT VERIFIED"

if command -v termux-clipboard-set >/dev/null 2>&1 &&
   command -v termux-clipboard-get >/dev/null 2>&1; then
    if termux-clipboard-set < "$REPORT"; then
        CLIP_SET="PASS"
        termux-clipboard-get > "$OUT/clipboard-readback.txt" || true
        if cmp -s "$REPORT" "$OUT/clipboard-readback.txt"; then
            CLIP_VERIFY="PASS: byte-for-byte verified"
        else
            CLIP_VERIFY="FAIL: readback mismatch"
        fi
    else
        CLIP_SET="FAIL"
    fi
fi

echo
echo "Clipboard SET: $CLIP_SET"
echo "Clipboard GET/CMP: $CLIP_VERIFY"
echo "Report: $REPORT"
echo "Log: $LOG"
echo "Checkpoint: $OUT"
