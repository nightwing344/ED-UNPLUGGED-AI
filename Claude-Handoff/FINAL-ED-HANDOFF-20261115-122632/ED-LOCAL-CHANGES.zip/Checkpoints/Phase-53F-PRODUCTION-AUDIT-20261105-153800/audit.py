import ast
import json
import sys
from pathlib import Path

source = Path(__file__).read_text(encoding="utf-8")
ast.parse(source)
print("[PASS] Python audit syntax parsed")

root = Path(sys.argv[1])
out = Path(sys.argv[2])

def read(path):
    p = Path(path)
    return p.read_text(encoding="utf-8", errors="replace") if p.exists() else ""

def count_words(path):
    return len(read(path).split())

results = []
for label in ("test-a-existing", "test-b-length-aware"):
    meta_path = out / f"{label}-metadata.json"
    if meta_path.exists():
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        results.append({
            "test": label,
            "words_in_saved_response": count_words(out / f"{label}-response.txt"),
            "metadata": meta
        })

(out / "artifact-analysis.json").write_text(
    json.dumps(results, indent=2), encoding="utf-8"
)
print("[PASS] Saved A/B artifacts analyzed")
print(json.dumps(results, indent=2))
