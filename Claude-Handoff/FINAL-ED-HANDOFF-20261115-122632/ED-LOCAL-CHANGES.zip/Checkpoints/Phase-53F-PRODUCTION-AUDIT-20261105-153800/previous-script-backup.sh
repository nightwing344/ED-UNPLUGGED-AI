#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

ROOT="$HOME/ED-GITHUB-COMPARE"
WEB="$ROOT/Interface/Web"
RUNTIME="$ROOT/Runtime"
CP="$ROOT/Checkpoints"
STAMP="$(date +%Y%m%d-%H%M%S)"
OUT="$CP/Phase-53F-PRODUCTION-AUDIT-$STAMP"
REPORT="$OUT/final-report.txt"
LOG="$OUT/diagnostic.log"
PY="$OUT/audit.py"
SELF="$HOME/ED-PHASE53F-PRODUCTION-AUDIT.sh"

mkdir -p "$OUT"
exec > >(tee -a "$LOG") 2>&1

PASS=0
FAIL=0
WARN=0
pass(){ PASS=$((PASS+1)); echo "[PASS] $*"; }
fail(){ FAIL=$((FAIL+1)); echo "[FAIL] $*"; }
warn(){ WARN=$((WARN+1)); echo "[WARN] $*"; }

echo "ED UNPLUGGED AI - PHASE 53F"
echo "Production-path read-only audit"
echo "Timestamp: $STAMP"
echo "Checkpoint: $OUT"
echo

# 1. Verify environment
[[ -d "$ROOT" ]] || { echo "[FATAL] Repository missing"; exit 1; }
[[ -d "$WEB" && -d "$RUNTIME" ]] || { echo "[FATAL] Expected project folders missing"; exit 1; }
[[ -d "$CP" ]] || { echo "[FATAL] Checkpoint folder missing"; exit 1; }
pass "Repository and project directories found"

for cmd in bash python git sha256sum cmp; do
    if command -v "$cmd" >/dev/null 2>&1; then
        pass "Dependency available: $cmd"
    else
        fail "Missing dependency: $cmd"
    fi
done
(( FAIL == 0 )) || exit 1

# 2. Back up this script if a previous copy exists.
if [[ -f "$SELF" ]]; then
    cp -p "$SELF" "$OUT/previous-script-backup.sh"
    cmp -s "$SELF" "$OUT/previous-script-backup.sh" &&
        pass "Previous Phase 53F script backed up and verified" ||
        fail "Previous script backup mismatch"
else
    pass "No previous Phase 53F script to back up"
fi

# 3. Identify the latest Phase 53E V2 checkpoint.
V2="$(
    find "$CP" -maxdepth 1 -type d \
      -name 'Phase-53E-V2-*' -print 2>/dev/null |
    sort | tail -n 1
)"

[[ -n "$V2" ]] || { echo "[FATAL] Phase 53E V2 checkpoint not found"; exit 1; }

echo "$V2" > "$OUT/source-checkpoint.txt"
pass "Phase 53E V2 checkpoint found"

# 4. Inspect process table without signalling processes.
: > "$OUT/process-inspection.txt"
MATCHES=0

for proc in /proc/[0-9]*; do
    [[ -r "$proc/cmdline" ]] || continue
    PID="${proc##*/}"
    CMD="$(tr '\0' ' ' < "$proc/cmdline" 2>/dev/null || true)"
    [[ -n "$CMD" ]] || continue

    case "$CMD" in
      *ED-PHASE53E-CONTROLLED-TEST.sh*|*Phase-53E-CONTROLLED-20261105-152520/phase53e_test.py*)
        MATCHES=$((MATCHES+1))
        {
            echo "PID=$PID"
            echo "COMMAND=$CMD"
            grep -E '^(Name|State|PPid|VmRSS):' "$proc/status" 2>/dev/null || true
            echo "CWD=$(readlink "$proc/cwd" 2>/dev/null || true)"
            echo
        } >> "$OUT/process-inspection.txt"
        ;;
    esac
done

if (( MATCHES > 0 )); then
    warn "Found $MATCHES process entries matching the previous Phase 53E run"
else
    pass "No matching previous Phase 53E process found"
fi

# 5. Inspect relevant source files. No source file is executed.
HELPER="$RUNTIME/ed-ask-stream-v1.sh"
SERVER="$WEB/server.ts"
HTML="$WEB/index.html"

for f in "$HELPER" "$SERVER" "$HTML"; do
    if [[ -s "$f" ]]; then
        sha256sum "$f"
        pass "Source file present: ${f#"$ROOT/"}"
    else
        warn "Source file missing or empty: $f"
    fi
done > "$OUT/source-inventory.txt" 2>&1

# Capture focused source references.
if [[ -f "$HELPER" ]]; then
    grep -n -E \
      'REQUEST=|IDENTITY=|PROMPT=|num_predict|MEMORY_CONTEXT|ED_RETRIEVAL_QUERY|STRICT_OUTPUT|timeout_seconds|api/generate|ollama serve|ollama list' \
      "$HELPER" > "$OUT/helper-relevant-lines.txt" || true
    cp "$HELPER" "$OUT/helper-source-copy.sh"
    cmp -s "$HELPER" "$OUT/helper-source-copy.sh" &&
        pass "Runtime helper source copied and verified"
fi

if [[ -f "$SERVER" ]]; then
    grep -n -E \
      'compactPrompt|responseRules|modeDirective|spawn\\(|ED_RUNTIME_TIMEOUT_MS|300000|/api/ed/chat/stream|memoryContext|history.slice' \
      "$SERVER" > "$OUT/backend-relevant-lines.txt" || true
fi

if [[ -f "$HTML" ]]; then
    grep -n -E \
      '315000|AbortController|consumeJuniorStream|api/ed/chat/stream|event === "token"|event.type' \
      "$HTML" > "$OUT/frontend-relevant-lines.txt" || true
fi

# 6. Preserve and inspect actual isolated A/B prompts and results.
for name in \
    test-a-existing-prompt.txt \
    test-a-existing-response.txt \
    test-a-existing-metadata.json \
    test-b-length-aware-prompt.txt \
    test-b-length-aware-response.txt \
    test-b-length-aware-metadata.json \
    comparison.txt; do
    if [[ -s "$V2/$name" ]]; then
        cp "$V2/$name" "$OUT/$name"
        pass "Captured Phase 53E artifact: $name"
    else
        warn "Missing Phase 53E artifact: $name"
    fi
done

# 7. GET-only Ollama process inspection.
if command -v curl >/dev/null 2>&1; then
    HTTP="$(
      curl --silent --max-time 5 \
        -o "$OUT/ollama-ps.json" \
        -w '%{http_code}' \
        http://127.0.0.1:11434/api/ps 2>/dev/null || true
    )"
    if [[ "$HTTP" == "200" ]]; then
        pass "Ollama process-inspection endpoint returned HTTP 200"
    else
        warn "Ollama process-inspection endpoint unavailable: HTTP ${HTTP:-none}"
    fi
else
    warn "curl unavailable; Ollama process inspection skipped"
fi

# 8. Record Git state read-only.
git -C "$ROOT" status --short --branch > "$OUT/git-status.txt" 2>&1 &&
    pass "Git state captured read-only" ||
    warn "Git status command did not complete"

git -C "$ROOT" diff --stat > "$OUT/git-diff-stat.txt" 2>&1 || true

# 9. Create an independent Python audit parser.
cat > "$PY" <<'PYTHON'
import ast
import json
import sys
from pathlib import Path

source = Path(__file__).read_text(encoding="utf-8")
ast.parse(source)
print("[PASS] Python audit syntax parsed")

root = Path(sys.argv[1])
out = Path(sys.argv[2])

def read(path):
    p = Path(path)
    return p.read_text(encoding="utf-8", errors="replace") if p.exists() else ""

def count_words(path):
    return len(read(path).split())

results = []
for label in ("test-a-existing", "test-b-length-aware"):
    meta_path = out / f"{label}-metadata.json"
    if meta_path.exists():
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        results.append({
            "test": label,
            "words_in_saved_response": count_words(out / f"{label}-response.txt"),
            "metadata": meta
        })

(out / "artifact-analysis.json").write_text(
    json.dumps(results, indent=2), encoding="utf-8"
)
print("[PASS] Saved A/B artifacts analyzed")
print(json.dumps(results, indent=2))
PYTHON

bash -n "$SELF" && pass "Bash syntax check" || fail "Bash syntax check"
python -m py_compile "$PY" && pass "Python syntax check" || fail "Python syntax check"

if (( FAIL == 0 )); then
    python -u "$PY" "$ROOT" "$OUT" &&
        pass "Offline artifact analysis completed" ||
        fail "Offline artifact analysis failed"
fi

# 10. Report.
RESULT="PASSED READ-ONLY AUDIT"
(( FAIL > 0 )) && RESULT="FAILED: one or more audit checks failed"
(( MATCHES > 0 )) && RESULT="AUDIT COMPLETE: previous process still requires review"

{
    echo "ED UNPLUGGED AI - PHASE 53F FINAL REPORT"
    echo "Timestamp: $STAMP"
    echo "Result: $RESULT"
    echo "Passed: $PASS"
    echo "Failed: $FAIL"
    echo "Warnings: $WARN"
    echo "Previous process matches: $MATCHES"
    echo
    echo "Phase 53E V2 source checkpoint: $V2"
    echo "Audit checkpoint: $OUT"
    echo
    echo "=== PROCESS INSPECTION ==="
    cat "$OUT/process-inspection.txt"
    echo
    echo "=== HELPER RELEVANT LINES ==="
    cat "$OUT/helper-relevant-lines.txt" 2>/dev/null || true
    echo
    echo "=== BACKEND RELEVANT LINES ==="
    cat "$OUT/backend-relevant-lines.txt" 2>/dev/null || true
    echo
    echo "=== FRONTEND RELEVANT LINES ==="
    cat "$OUT/frontend-relevant-lines.txt" 2>/dev/null || true
    echo
    echo "=== PHASE 53E COMPARISON ==="
    cat "$OUT/comparison.txt" 2>/dev/null || true
    echo
    echo "=== GIT STATUS (READ ONLY) ==="
    cat "$OUT/git-status.txt" 2>/dev/null || true
    echo
    echo "Source edits: NONE"
    echo "Build: NOT RUN"
    echo "Inference requests: NONE"
    echo "Runtime helper execution: NONE"
    echo "Service restart: NONE"
    echo "Process termination: NONE"
    echo "Git mutation: NONE"
    echo
    echo "Diagnostic log: $LOG"
} > "$REPORT"

echo
echo "========== FINAL REPORT =========="
cat "$REPORT"

# Mandatory clipboard SET -> GET -> CMP.
CLIP_SET="NOT AVAILABLE"
CLIP_VERIFY="NOT VERIFIED"

if command -v termux-clipboard-set >/dev/null 2>&1 &&
   command -v termux-clipboard-get >/dev/null 2>&1; then
    if termux-clipboard-set < "$REPORT"; then
        CLIP_SET="PASS"
        termux-clipboard-get > "$OUT/clipboard-readback.txt" || true
        if cmp -s "$REPORT" "$OUT/clipboard-readback.txt"; then
            CLIP_VERIFY="PASS: byte-for-byte verified"
        else
            CLIP_VERIFY="FAIL: clipboard readback differs"
        fi
    else
        CLIP_SET="FAIL"
    fi
fi

echo
echo "Clipboard SET: $CLIP_SET"
echo "Clipboard GET/CMP: $CLIP_VERIFY"
echo "Final report: $REPORT"
echo "Diagnostic log: $LOG"
echo "Checkpoint: $OUT"
