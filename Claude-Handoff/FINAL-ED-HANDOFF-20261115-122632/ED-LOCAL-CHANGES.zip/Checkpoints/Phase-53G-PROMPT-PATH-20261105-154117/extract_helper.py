import re
import sys
from pathlib import Path

src = Path(sys.argv[1])
out = Path(sys.argv[2])
lines = src.read_text(encoding="utf-8", errors="replace").splitlines()

patterns = [
    r"REQUEST=",
    r"STRICT_OUTPUT",
    r"MEMORY_CONTEXT",
    r"ED_RETRIEVAL_QUERY",
    r"IDENTITY=",
    r"PROMPT=",
    r"num_predict",
    r"api/generate",
    r"timeout_seconds",
    r"MODEL=",
    r"ollama list",
    r"ollama serve",
]

hits = []
for i, line in enumerate(lines):
    if any(re.search(p, line, re.I) for p in patterns):
        hits.append(i)

selected = set()
for i in hits:
    selected.update(range(max(0, i-5), min(len(lines), i+9)))

with out.open("w", encoding="utf-8") as f:
    f.write(f"Helper source: {src}\n")
    f.write(f"Total lines: {len(lines)}\n")
    f.write(f"Matched lines: {len(hits)}\n\n")
    previous = -2
    for i in sorted(selected):
        if i > previous + 1:
            f.write("\n--- context boundary ---\n")
        f.write(f"{i+1:5}: {lines[i]}\n")
        previous = i

print(f"[PASS] Helper extraction complete: {len(hits)} matched lines")
