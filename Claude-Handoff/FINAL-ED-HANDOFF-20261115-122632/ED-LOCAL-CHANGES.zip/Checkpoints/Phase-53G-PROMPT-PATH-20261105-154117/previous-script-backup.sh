#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

ROOT="$HOME/ED-GITHUB-COMPARE"
WEB="$ROOT/Interface/Web"
RUNTIME="$ROOT/Runtime"
CP="$ROOT/Checkpoints"
STAMP="$(date +%Y%m%d-%H%M%S)"
OUT="$CP/Phase-53G-PROMPT-PATH-$STAMP"
SELF="$HOME/ED-PHASE53G-PROMPT-PATH-AUDIT.sh"
REPORT="$OUT/final-report.txt"
LOG="$OUT/diagnostic.log"

mkdir -p "$OUT"
exec > >(tee -a "$LOG") 2>&1

PASS=0
FAIL=0
WARN=0

pass(){ PASS=$((PASS+1)); echo "[PASS] $*"; }
fail(){ FAIL=$((FAIL+1)); echo "[FAIL] $*"; }
warn(){ WARN=$((WARN+1)); echo "[WARN] $*"; }

echo "ED UNPLUGGED AI - PHASE 53G"
echo "Production prompt-path audit"
echo "Timestamp: $STAMP"
echo "Checkpoint: $OUT"
echo

# 1. Environment preflight
[[ -d "$ROOT" ]] || { echo "[FATAL] Repository missing: $ROOT"; exit 1; }
[[ -d "$WEB" && -d "$RUNTIME" && -d "$CP" ]] ||
    { echo "[FATAL] Expected project directories missing"; exit 1; }

for cmd in bash python git sha256sum cmp; do
    command -v "$cmd" >/dev/null 2>&1 &&
        pass "Dependency available: $cmd" ||
        fail "Dependency missing: $cmd"
done
(( FAIL == 0 )) || exit 1

# 2. Preserve the previous script, if present.
if [[ -f "$SELF" ]]; then
    cp -p "$SELF" "$OUT/previous-script-backup.sh"
    cmp -s "$SELF" "$OUT/previous-script-backup.sh" &&
        pass "Previous script backup verified" ||
        fail "Previous script backup mismatch"
else
    pass "No previous Phase 53G script to back up"
fi

HELPER="$RUNTIME/ed-ask-stream-v1.sh"
SERVER="$WEB/server.ts"
HTML="$WEB/index.html"
DIST="$WEB/dist/server.cjs"

# 3. Copy source evidence into this checkpoint.
for f in "$HELPER" "$SERVER" "$HTML" "$DIST"; do
    if [[ -s "$f" ]]; then
        dest="$OUT/$(basename "$f").evidence"
        cp -p "$f" "$dest"
        if cmp -s "$f" "$dest"; then
            pass "Evidence copy verified: ${f#"$ROOT/"}"
        else
            fail "Evidence copy mismatch: $f"
        fi
        sha256sum "$f" >> "$OUT/source-hashes.txt"
    else
        warn "Missing or empty source file: ${f#"$ROOT/"}"
    fi
done

(( FAIL == 0 )) || exit 1

# 4. Extract prompt construction and handoff from backend.
cat > "$OUT/extract_backend.py" <<'PYTHON'
import re
import sys
from pathlib import Path

src = Path(sys.argv[1])
out = Path(sys.argv[2])
lines = src.read_text(encoding="utf-8", errors="replace").splitlines()

patterns = [
    r"api/ed/chat",
    r"compactPrompt",
    r"responseRules",
    r"modeDirective",
    r"resetDirective",
    r"memoryContext",
    r"ED_RETRIEVAL_QUERY",
    r"spawn\s*\(",
    r"ed-ask-stream",
    r"ED_RUNTIME_TIMEOUT_MS",
    r"timeout",
    r"request\.body",
    r"body\.message",
    r"body\.history",
    r"body\.mode",
]

hits = []
for i, line in enumerate(lines):
    if any(re.search(p, line, re.I) for p in patterns):
        hits.append(i)

selected = set()
for i in hits:
    selected.update(range(max(0, i-5), min(len(lines), i+7)))

with out.open("w", encoding="utf-8") as f:
    f.write(f"Backend source: {src}\n")
    f.write(f"Total lines: {len(lines)}\n")
    f.write(f"Matched lines: {len(hits)}\n\n")
    previous = -2
    for i in sorted(selected):
        if i > previous + 1:
            f.write("\n--- context boundary ---\n")
        f.write(f"{i+1:5}: {lines[i]}\n")
        previous = i

print(f"[PASS] Backend extraction complete: {len(hits)} matched lines")
PYTHON

# 5. Extract helper's prompt, retrieval, and inference construction.
cat > "$OUT/extract_helper.py" <<'PYTHON'
import re
import sys
from pathlib import Path

src = Path(sys.argv[1])
out = Path(sys.argv[2])
lines = src.read_text(encoding="utf-8", errors="replace").splitlines()

patterns = [
    r"REQUEST=",
    r"STRICT_OUTPUT",
    r"MEMORY_CONTEXT",
    r"ED_RETRIEVAL_QUERY",
    r"IDENTITY=",
    r"PROMPT=",
    r"num_predict",
    r"api/generate",
    r"timeout_seconds",
    r"MODEL=",
    r"ollama list",
    r"ollama serve",
]

hits = []
for i, line in enumerate(lines):
    if any(re.search(p, line, re.I) for p in patterns):
        hits.append(i)

selected = set()
for i in hits:
    selected.update(range(max(0, i-5), min(len(lines), i+9)))

with out.open("w", encoding="utf-8") as f:
    f.write(f"Helper source: {src}\n")
    f.write(f"Total lines: {len(lines)}\n")
    f.write(f"Matched lines: {len(hits)}\n\n")
    previous = -2
    for i in sorted(selected):
        if i > previous + 1:
            f.write("\n--- context boundary ---\n")
        f.write(f"{i+1:5}: {lines[i]}\n")
        previous = i

print(f"[PASS] Helper extraction complete: {len(hits)} matched lines")
PYTHON

python -m py_compile "$OUT/extract_backend.py" &&
    pass "Backend extractor syntax valid" ||
    fail "Backend extractor syntax invalid"

python -m py_compile "$OUT/extract_helper.py" &&
    pass "Helper extractor syntax valid" ||
    fail "Helper extractor syntax invalid"

(( FAIL == 0 )) || exit 1

python -u "$OUT/extract_backend.py" \
    "$SERVER" "$OUT/backend-prompt-path.txt" &&
    pass "Backend prompt path extracted" ||
    fail "Backend prompt extraction failed"

python -u "$OUT/extract_helper.py" \
    "$HELPER" "$OUT/helper-prompt-path.txt" &&
    pass "Helper prompt path extracted" ||
    fail "Helper prompt extraction failed"

# 6. Record complete helper prompt/inference section.
sed -n '150,275p' "$HELPER" > "$OUT/helper-lines-150-275.txt"
pass "Helper prompt and Ollama request section captured"

# 7. Record current backend diff without changing Git.
git -C "$ROOT" diff -- "$SERVER" > "$OUT/server-current-diff.patch" &&
    pass "Existing backend diff captured read-only" ||
    warn "Could not capture backend diff"

git -C "$ROOT" status --short --branch > "$OUT/git-status.txt" &&
    pass "Existing Git state captured read-only" ||
    warn "Git status unavailable"

# 8. Inspect previous Phase 53E/53F artifacts.
for f in \
 "$CP/Phase-53E-V2-20261105-153229/comparison.txt" \
 "$CP/Phase-53F-PRODUCTION-AUDIT-20261105-153800/helper-relevant-lines.txt" \
 "$CP/Phase-53F-PRODUCTION-AUDIT-20261105-153800/backend-relevant-lines.txt"; do
    if [[ -s "$f" ]]; then
        cp -p "$f" "$OUT/$(basename "$f").prior-evidence"
        pass "Prior evidence copied: $(basename "$f")"
    else
        warn "Prior evidence not found: $f"
    fi
done

# 9. Read-only process check for previous Phase 53E test.
python - "$OUT/process-inspection.txt" <<'PYTHON'
import os
import sys
from pathlib import Path

out = Path(sys.argv[1])
needles = (
    "ED-PHASE53E-CONTROLLED-TEST.sh",
    "Phase-53E-CONTROLLED-20261105-152520/phase53e_test.py",
)
found = []

for p in Path("/proc").glob("[0-9]*"):
    try:
        cmd = (p / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
        if not cmd:
            continue
        if any(n in cmd for n in needles):
            status = (p / "status").read_text(errors="replace")
            cwd = os.readlink(p / "cwd")
            found.append(f"PID={p.name}\nCOMMAND={cmd}\nCWD={cwd}\n{status}\n")
    except (OSError, PermissionError):
        continue

out.write_text("\n".join(found), encoding="utf-8")
print(f"[PASS] Process inspection complete; matches={len(found)}")
PYTHON

if [[ -s "$OUT/process-inspection.txt" ]]; then
    warn "Previous Phase 53E process still appears in process table"
else
    pass "No previous Phase 53E process found"
fi

# 10. Offline consistency checks. No inference or network request.
python - "$OUT/backend-prompt-path.txt" "$OUT/helper-prompt-path.txt" "$OUT/consistency-checks.txt" <<'PYTHON'
import sys
from pathlib import Path

backend = Path(sys.argv[1]).read_text(errors="replace")
helper = Path(sys.argv[2]).read_text(errors="replace")
out = Path(sys.argv[3])

checks = {
    "backend_compact_prompt_reference": "compactPrompt" in backend,
    "backend_spawn_reference": "spawn" in backend,
    "helper_request_argument": "REQUEST=" in helper,
    "helper_identity_prompt": "IDENTITY=" in helper,
    "helper_final_prompt": "PROMPT=" in helper,
    "helper_output_budget": "num_predict" in helper,
    "helper_local_generate_endpoint": "api/generate" in helper,
}

lines = [f"{'PASS' if ok else 'NOT FOUND'}: {name}" for name, ok in checks.items()]
out.write_text("\n".join(lines) + "\n", encoding="utf-8")
for line in lines:
    print(line)

print(f"Checks present: {sum(checks.values())}/{len(checks)}")
PYTHON

pass "Offline consistency checks completed"

# 11. Bash syntax and self-check.
bash -n "$SELF" &&
    pass "Phase 53G Bash syntax check" ||
    fail "Phase 53G Bash syntax check failed"

(( FAIL == 0 )) || {
    echo "[STOP] Audit failures detected. No repair attempted."
    exit 1
}

# 12. Create preliminary report.
RESULT="PASSED: READ-ONLY PROMPT-PATH AUDIT"
(( WARN > 0 )) && RESULT="COMPLETED WITH WARNINGS"

{
    echo "ED UNPLUGGED AI - PHASE 53G FINAL REPORT"
    echo "Timestamp: $STAMP"
    echo "Result: $RESULT"
    echo "Passed: $PASS"
    echo "Failed: $FAIL"
    echo "Warnings: $WARN"
    echo
    echo "Checkpoint: $OUT"
    echo
    echo "=== BACKEND PROMPT PATH ==="
    cat "$OUT/backend-prompt-path.txt"
    echo
    echo "=== HELPER PROMPT PATH ==="
    cat "$OUT/helper-prompt-path.txt"
    echo
    echo "=== HELPER INFERENCE SECTION ==="
    cat "$OUT/helper-lines-150-275.txt"
    echo
    echo "=== CONSISTENCY CHECKS ==="
    cat "$OUT/consistency-checks.txt"
    echo
    echo "=== PREVIOUS PROCESS INSPECTION ==="
    cat "$OUT/process-inspection.txt"
    echo
    echo "=== GIT STATUS ==="
    cat "$OUT/git-status.txt"
    echo
    echo "Source edits: NONE"
    echo "Build: NOT RUN"
    echo "Inference requests: NONE"
    echo "Runtime helper execution: NONE"
    echo "Live ED requests: NONE"
    echo "Service restart: NONE"
    echo "Process termination: NONE"
    echo "Git mutation: NONE"
    echo
    echo "Diagnostic log: $LOG"
} > "$OUT/preliminary-report.txt"

# First clipboard pass.
CLIP_SET="NOT AVAILABLE"
CLIP_VERIFY="NOT VERIFIED"

if command -v termux-clipboard-set >/dev/null 2>&1 &&
   command -v termux-clipboard-get >/dev/null 2>&1; then
    if termux-clipboard-set < "$OUT/preliminary-report.txt"; then
        CLIP_SET="PASS"
        termux-clipboard-get > "$OUT/clipboard-readback-1.txt" || true
        if cmp -s "$OUT/preliminary-report.txt" "$OUT/clipboard-readback-1.txt"; then
            CLIP_VERIFY="PASS"
        else
            CLIP_VERIFY="FAIL"
        fi
    else
        CLIP_SET="FAIL"
    fi
fi

# 13. Final report includes clipboard result.
{
    cat "$OUT/preliminary-report.txt"
    echo
    echo "Clipboard first-pass SET: $CLIP_SET"
    echo "Clipboard first-pass verification: $CLIP_VERIFY"
} > "$REPORT"

# Final clipboard SET -> GET -> CMP.
FINAL_SET="NOT AVAILABLE"
FINAL_VERIFY="NOT VERIFIED"

if command -v termux-clipboard-set >/dev/null 2>&1 &&
   command -v termux-clipboard-get >/dev/null 2>&1; then
    if termux-clipboard-set < "$REPORT"; then
        FINAL_SET="PASS"
        termux-clipboard-get > "$OUT/clipboard-final-readback.txt" || true
        if cmp -s "$REPORT" "$OUT/clipboard-final-readback.txt"; then
            FINAL_VERIFY="PASS: BYTE-FOR-BYTE VERIFIED"
        else
            FINAL_VERIFY="FAIL: READBACK MISMATCH"
        fi
    else
        FINAL_SET="FAIL"
    fi
fi

echo
echo "========== PHASE 53G FINAL REPORT =========="
cat "$REPORT"
echo
echo "FINAL CLIPBOARD SET: $FINAL_SET"
echo "FINAL CLIPBOARD GET/CMP: $FINAL_VERIFY"
echo "Report: $REPORT"
echo "Log: $LOG"
echo "Checkpoint: $OUT"
