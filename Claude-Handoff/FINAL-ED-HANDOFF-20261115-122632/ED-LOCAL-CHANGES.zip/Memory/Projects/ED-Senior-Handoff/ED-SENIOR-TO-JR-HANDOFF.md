# ED Senior → ED Unplugged AI (Jr): Implementation Handoff

## Mission
Continue the existing ED Unplugged AI project. Preserve its established Constitution, Genesis plan, working implementation, and current checkpoint. Do not redesign from scratch.

## Relationship
ED Senior is the ChatGPT-based partner. Jr is the user's self-hosted ED Unplugged AI system. The handoff connects their work; they are not separate competing products.

## Required architecture
- One unified ED persona coordinating all capabilities.
- Persistent memory and context retrieval.
- A Knowledge Gateway for importing files, books, PDFs, code, images, audio, video transcripts, websites, and conversations.
- Concepts and relationships that can be retrieved and reused across subjects.
- Specialist capabilities coordinated by ED rather than disconnected assistants.
- A mission/task system, clear truth and uncertainty labels, source tracking, and verification.
- Local-first reasoning, with cloud fallback only when configured and available.
- Flexible multi-domain work.

## Safe implementation order
1. Read the original Constitution, Genesis plan, and Master Vision if available. Preserve originals verbatim.
2. Inspect current source, Git state, running services, and the existing working checkpoint before changes.
3. Create a new recovery checkpoint before modifying anything.
4. Preserve the working chat path.
5. Implement the smallest useful Knowledge Gateway: ingest, index, retrieve, show sources, report errors, and connect results to normal ED chat.
6. Test with known documents and questions before expanding.

## Safety requirements
- Do not delete app data, uninstall the app, overwrite original vision documents, or interrupt the live server without explicit approval.
- Do not claim a feature works without testing it.
- Do not invent missing Constitution or Genesis text. Clearly report any original document that could not be found.
- Avoid repeated diagnostics without a concrete implementation goal.
- Report changed files, backups, tests, remaining work, and restoration steps.

## Working checkpoint
Known checkpoint reported in the previous session:
ED-GITHUB-COMPARE/Checkpoints/ED-WORKING-20261024-033618

Verify that it still exists before relying on it.
