# ED Retrieval Registry

Purpose:
Find relevant stored knowledge.

Components:

Index:
Searchable memory map.

Results:
Generated context packages.

Logs:
Search history.

Status:
ACTIVE
