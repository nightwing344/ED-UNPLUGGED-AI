#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
ED_CORE="${ED_CORE:-$(dirname "$SCRIPT_DIR")}"
RUNTIME="${ED_RUNTIME_DIR:-$SCRIPT_DIR}"
if [ -d "/storage/emulated/0/ED/Memory" ]; then
    MEMORY="${ED_MEMORY_ROOT:-/storage/emulated/0/ED/Memory}"
else
    MEMORY="${ED_MEMORY_ROOT:-$ED_CORE/Memory}"
fi
REPORTS="$ED_CORE/Reports"

REQUEST="${*:-}"

if [ -z "$REQUEST" ]; then
    echo "Usage: ED ask <question>"
    exit 1
fi

mkdir -p "$REPORTS"

echo "================================"
echo " ED INTELLIGENCE RUNTIME v1"
echo "================================"
echo

# ------------------------------------------------
# MODEL BACKEND
# ------------------------------------------------

if ! command -v ollama >/dev/null 2>&1; then
    echo "ERROR: Ollama is not installed."
    exit 20
fi

if ! ollama list >/dev/null 2>&1; then

    echo "Starting local intelligence backend..."

    nohup ollama serve \
        > "$REPORTS/ollama-runtime.log" \
        2>&1 &

    OLLAMA_PID=$!

    READY=0

    for _ in 1 2 3 4 5 6 7 8 9 10; do
        sleep 1

        if ollama list >/dev/null 2>&1; then
            READY=1
            break
        fi
    done

    if [ "$READY" -ne 1 ]; then
        echo "ERROR: Ollama failed to become ready."
        echo "PID attempted: $OLLAMA_PID"
        echo "Log: $REPORTS/ollama-runtime.log"
        exit 21
    fi
fi

# ------------------------------------------------
# MODEL DISCOVERY
# ------------------------------------------------

MODEL="$(
    ollama list 2>/dev/null |
    awk 'NR > 1 && NF {print $1; exit}'
)"

if [ -z "$MODEL" ]; then
    echo "ERROR: Ollama is running but no local model is installed."
    echo
    echo "A model must be installed before ED can reason locally."
    exit 22
fi

# Prefer ED's known model when installed.
if ollama list 2>/dev/null |
   awk 'NR > 1 {print $1}' |
   grep -Fxq 'llama3.2:3b'; then

    MODEL="llama3.2:3b"
fi

# ------------------------------------------------
# READ-ONLY MEMORY RETRIEVAL
# ------------------------------------------------

MEMORY_CONTEXT="No relevant persistent memory was found."
MATCHES=""

REQUEST_LC="$(printf '%s' "$REQUEST" | tr '[:upper:]' '[:lower:]')"
STRICT_OUTPUT=0
if [[ "$REQUEST_LC" =~ (exactly|only)[^[:cntrl:]]{0,100}(word|number|character|letter|token|nothing[[:space:]]+else|json) ]] ||
   [[ "$REQUEST_LC" =~ (reply|respond|output|return)[^[:cntrl:]]{0,100}(exactly|only) ]] ||
   [[ "$REQUEST_LC" =~ ^[[:space:]]*(what[[:space:]]+is[[:space:]]+)?[0-9]+[[:space:]]*[-+*/][[:space:]]*[0-9]+[[:space:]]*\?[[:space:]]*(just|only|give|reply|answer) ]]; then
  STRICT_OUTPUT=1
fi

if [ -d "$MEMORY" ] && [ -f "$RUNTIME/ed-memory-retrieve.py" ] && [ "$STRICT_OUTPUT" -eq 0 ]; then

    RETRIEVAL_JSON="$(
        python "$RUNTIME/ed-memory-retrieve.py" "${ED_RETRIEVAL_QUERY:-$REQUEST}" --root "$MEMORY" --root "/storage/emulated/0/ED/Core" --root "/storage/emulated/0/ED/Knowledge" --limit 5 2>/dev/null || true
    )"

    if [ -n "$RETRIEVAL_JSON" ]; then
        MATCHES="$(
            RETRIEVAL_JSON="$RETRIEVAL_JSON" MEMORY="$MEMORY" python - <<'PYMATCH'
import json, os

try:
    data=json.loads(os.environ["RETRIEVAL_JSON"])
except Exception:
    raise SystemExit(0)

root=os.environ["MEMORY"]

for item in data.get("results", []):
    rel=item.get("path")
    if rel:
        print(os.path.join(root, rel))
PYMATCH
        )"
    fi

    if [ -n "$MATCHES" ]; then
        MEMORY_CONTEXT=""

        while IFS= read -r FILE; do
            [ -f "$FILE" ] || continue

            REL="${FILE#"$MEMORY"/}"

            CONTENT="$(
                RETRIEVAL_JSON="$RETRIEVAL_JSON" REL="$REL" python - <<'PYEXCERPT'
import json, os

try:
    data=json.loads(os.environ["RETRIEVAL_JSON"])
except Exception:
    raise SystemExit(0)

rel=os.environ["REL"]

for item in data.get("results", []):
    if item.get("path") == rel:
        print(item.get("excerpt", ""))
        break
PYEXCERPT
            )"

            if [ -z "$CONTENT" ]; then
                CONTENT="$(head -40 "$FILE" 2>/dev/null || true)"
            fi

            MEMORY_CONTEXT="${MEMORY_CONTEXT}
--- MEMORY SOURCE: $REL ---
$CONTENT
"
        done <<< "$MATCHES"
    fi
fi

# ------------------------------------------------
# IDENTITY
# ------------------------------------------------

IDENTITY="You are ED (ED Unplugged AI), an operating intelligence assistant.

You are not merely a command dispatcher.

Your job is to understand the user's request, reason about it, use relevant supplied memory when useful, and give a direct useful response.

Core rules:
- Never claim an action occurred unless it actually occurred.
- Never claim a subsystem is working merely because its file exists.
- Distinguish real execution from planned capability.
- User retains authority over destructive or persistent changes.
- Do not silently write memory.
- Do not invent memories.
- If supplied memory is irrelevant, ignore it.
- Be concise when the request is simple.
- When the user requests a specific length or depth, honor it fully; do not truncate a requested long-form answer merely to be brief.
- Respond to the user's actual request rather than describing the architecture."

PROMPT="$IDENTITY

PERSISTENT MEMORY CONTEXT:
$MEMORY_CONTEXT

USER REQUEST:
$REQUEST

ED RESPONSE:"

# ------------------------------------------------
# ------------------------------------------------
# STREAMING LOCAL INFERENCE
# ------------------------------------------------

echo "Backend: Ollama"
echo "Model:   $MODEL"
echo "Memory:  read-only"
echo
echo "MEMORY SOURCES:"

if [ -n "$MATCHES" ]; then
    while IFS= read -r FILE; do
        [ -f "$FILE" ] || continue
        echo "- ${FILE#"$MEMORY"/}"
    done <<< "$MATCHES"
else
    echo "- none"
fi

echo
echo "ED RESPONSE:"
echo

MODEL="$MODEL" PROMPT="$PROMPT" python - <<'PYAPI'
import json, os, sys, urllib.request

def emit(kind, **fields):
    print("ED_STREAM:" + json.dumps({"type": kind, **fields}, ensure_ascii=False),
          flush=True)

try:
    data = json.dumps({
        "model": os.environ["MODEL"],
        "prompt": os.environ["PROMPT"],
        "stream": True,
        "options": {"num_predict": 2048}
    }).encode()

    url = os.environ.get(
        "ED_OLLAMA_URL",
        "http://127.0.0.1:11434/api/generate"
    )

    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"}
    )

    timeout_seconds = max(
        1.0,
        float(os.environ.get("ED_INFERENCE_TIMEOUT_SECONDS", "300"))
    )

    received_done = False

    with urllib.request.urlopen(req, timeout=timeout_seconds) as response:
        for raw_line in response:
            if not raw_line.strip():
                continue

            item = json.loads(raw_line.decode("utf-8"))
            chunk = item.get("response", "")

            if chunk:
                emit("token", text=chunk)

            if item.get("error"):
                raise RuntimeError(str(item["error"]))

            if item.get("done"):
                received_done = True
                emit("backend_done")
                break

    if not received_done:
        raise RuntimeError("Ollama stream ended without a done marker")

except Exception as exc:
    emit("error", message=str(exc))
    sys.exit(23)
PYAPI

echo
echo "================================"
echo " RESPONSE COMPLETE"
echo "================================"
