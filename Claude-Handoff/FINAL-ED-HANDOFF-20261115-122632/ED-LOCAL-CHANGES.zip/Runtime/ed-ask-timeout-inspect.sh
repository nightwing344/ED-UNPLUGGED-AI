#!/data/data/com.termux/files/usr/bin/bash
set +e

BASE="$HOME/ED-GITHUB-COMPARE"
ASK="$BASE/Runtime/ed-ask-v1.sh"
WRAPPER="$BASE/Runtime/ED"
REPORT_DIR="$BASE/Reports"
mkdir -p "$REPORT_DIR" || exit 2
REPORT="$REPORT_DIR/ED-ASK-TIMEOUT-INSPECT-$(date +%Y%m%d-%H%M%S).log"

{
echo '===== ED ASK TIMEOUT CONFIGURATION INSPECTION ====='
date
echo "REPORT=$REPORT"
echo 'SAFETY=Read-only; no files edited; no services restarted.'
echo

for FILE in "$ASK" "$WRAPPER"; do
echo "===== FILE: $FILE ====="
if [ ! -r "$FILE" ]; then
echo 'FILE_STATUS=MISSING_OR_UNREADABLE'
continue
fi
ls -l "$FILE"
echo '-- Relevant lines: request, timeout, model, endpoint --'
grep -nEi 'urlopen|timeout|11434|api/generate|api/chat|socket|OLLAMA|MODEL|generate|read_timeout|connect_timeout' "$FILE" | head -n 100
echo '-- File contents, first 180 lines --'
sed -n '1,180p' "$FILE"
echo
done

echo '===== END INSPECTION ====='
} 2>&1 | tee "$REPORT"

CLIP_COPY=UNAVAILABLE
CLIP_VERIFY=UNAVAILABLE
if command -v termux-clipboard-set >/dev/null 2>&1; then
if timeout 8s termux-clipboard-set < "$REPORT" >/dev/null 2>&1; then
CLIP_COPY=PASS
else
CLIP_COPY=FAILED_OR_TIMEOUT
fi
fi
if command -v termux-clipboard-get >/dev/null 2>&1; then
if timeout 8s termux-clipboard-get 2>/dev/null | grep -Fq 'ED ASK TIMEOUT CONFIGURATION INSPECTION'; then
CLIP_VERIFY=PASS
else
CLIP_VERIFY=NOT_CONFIRMED
fi
fi

printf '\nCLIPBOARD_COPY_FIRST_PASS=%s\nCLIPBOARD_VERIFY_FIRST_PASS=%s\n' "$CLIP_COPY" "$CLIP_VERIFY" >> "$REPORT"

if command -v termux-clipboard-set >/dev/null 2>&1 && timeout 8s termux-clipboard-set < "$REPORT" >/dev/null 2>&1; then
CLIP_FINAL=PASS
else
CLIP_FINAL=FAILED_OR_UNAVAILABLE
fi

echo "REPORT_PATH=$REPORT"
echo "CLIPBOARD_COPY_FINAL_REPORT=$CLIP_FINAL"
