#!/data/data/com.termux/files/usr/bin/bash
set +e
BASE="$HOME/ED-GITHUB-COMPARE"
mkdir -p "$BASE/Reports"
REPORT="$BASE/Reports/ED-LOCAL-MODEL-TEST-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee "$REPORT") 2>&1

echo "===== ED LOCAL MODEL + CLIPBOARD TEST ====="
date
echo "REPORT=$REPORT"

echo
echo "[1/3] Run local ED prompt"
"$BASE/Runtime/ED" ask "Reply with exactly: ED_LOCAL_MODEL_OK"
ED_EXIT=$?
echo
echo "ED_PROMPT_EXIT=$ED_EXIT"

echo
echo "[2/3] Copy report to Android clipboard"
if command -v termux-clipboard-set >/dev/null 2>&1; then
if termux-clipboard-set < "$REPORT"; then
echo "CLIPBOARD_COPY=COMMAND_SUCCEEDED"
else
echo "CLIPBOARD_COPY=FAILED"
fi
else
echo "CLIPBOARD_COPY=UNAVAILABLE (Termux:API command missing)"
fi

echo
echo "[3/3] Verify clipboard when supported"
if command -v termux-clipboard-get >/dev/null 2>&1; then
CLIP="$(termux-clipboard-get 2>&1)"
if printf '%s' "$CLIP" | grep -Fq "ED LOCAL MODEL + CLIPBOARD TEST"; then
echo "CLIPBOARD_VERIFY=PASS"
else
echo "CLIPBOARD_VERIFY=NOT_CONFIRMED"
printf '%s\n' "$CLIP" | head -c 300
echo
fi
else
echo "CLIPBOARD_VERIFY=UNAVAILABLE"
fi

echo
echo "FINAL_REPORT_PATH=$REPORT"
echo "===== END ====="
