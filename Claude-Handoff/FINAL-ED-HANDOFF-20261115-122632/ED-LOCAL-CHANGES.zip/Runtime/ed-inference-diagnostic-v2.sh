#!/data/data/com.termux/files/usr/bin/bash
set +e

BASE="$HOME/ED-GITHUB-COMPARE"
REPORT_DIR="$BASE/Reports"
mkdir -p "$REPORT_DIR" || exit 2
REPORT="$REPORT_DIR/ED-INFERENCE-DIAG-V2-$(date +%Y%m%d-%H%M%S).log"
ED_CMD="$BASE/Runtime/ED"
START=$SECONDS

{
echo "===== ED INFERENCE DIAGNOSTIC V2 ====="
date
echo "REPORT=$REPORT"
echo "SAFETY=Read-only; no files changed; no services restarted."
echo

echo "[1/3] Ollama API health"
if command -v curl >/dev/null 2>&1; then
curl -sS --max-time 5 
-o "$REPORT_DIR/.ed-ollama-tags.tmp" 
-w 'OLLAMA_HTTP_CODE=%{http_code}\nOLLAMA_SECONDS=%{time_total}\n' 
"http://127.0.0.1:11434/api/tags"
CURL_EXIT=$?
echo "OLLAMA_CURL_EXIT=$CURL_EXIT"
if [ "$CURL_EXIT" -eq 0 ] && [ -s "$REPORT_DIR/.ed-ollama-tags.tmp" ]; then
echo "OLLAMA_MODEL_LIST_RESPONSE:"
head -c 1500 "$REPORT_DIR/.ed-ollama-tags.tmp"
echo
fi
rm -f "$REPORT_DIR/.ed-ollama-tags.tmp"
else
echo "CURL=UNAVAILABLE"
fi

echo
echo "[2/3] Tiny ED prompt (20-second limit)"
if [ -x "$ED_CMD" ] && command -v timeout >/dev/null 2>&1; then
T0=$SECONDS
timeout 20s "$ED_CMD" ask "Reply with exactly: ED_DIAG_OK"
ED_EXIT=$?
echo
echo "ED_EXIT=$ED_EXIT"
echo "ED_ELAPSED_SECONDS=$((SECONDS-T0))"
case "$ED_EXIT" in
0)   echo "ED_TINY_PROMPT=PASS" ;;
124) echo "ED_TINY_PROMPT=TIMEOUT" ;;
*)   echo "ED_TINY_PROMPT=FAILED" ;;
esac
else
echo "ED_TINY_PROMPT=STOPPED_RUNTIME_OR_TIMEOUT_MISSING"
fi

echo
echo "[3/3] Summary"
echo "TOTAL_ELAPSED_SECONDS=$((SECONDS-START))"
echo "===== END DIAGNOSTIC ====="
} 2>&1 | tee "$REPORT"

CLIP_COPY=UNAVAILABLE
CLIP_VERIFY=UNAVAILABLE

if command -v termux-clipboard-set >/dev/null 2>&1; then
if timeout 8s termux-clipboard-set < "$REPORT" >/dev/null 2>&1; then
CLIP_COPY=PASS
else
CLIP_COPY=FAILED_OR_TIMEOUT
fi
fi

if command -v termux-clipboard-get >/dev/null 2>&1; then
if timeout 8s termux-clipboard-get 2>/dev/null |
grep -Fq "ED INFERENCE DIAGNOSTIC V2"; then
CLIP_VERIFY=PASS
else
CLIP_VERIFY=NOT_CONFIRMED
fi
fi

printf '\nCLIPBOARD_COPY_FIRST_PASS=%s\nCLIPBOARD_VERIFY_FIRST_PASS=%s\n' 
"$CLIP_COPY" "$CLIP_VERIFY" >> "$REPORT"

if command -v termux-clipboard-set >/dev/null 2>&1 &&
timeout 8s termux-clipboard-set < "$REPORT" >/dev/null 2>&1; then
CLIP_FINAL=PASS
else
CLIP_FINAL=FAILED_OR_UNAVAILABLE
fi

echo "REPORT_PATH=$REPORT"
echo "CLIPBOARD_COPY_FINAL_REPORT=$CLIP_FINAL"
