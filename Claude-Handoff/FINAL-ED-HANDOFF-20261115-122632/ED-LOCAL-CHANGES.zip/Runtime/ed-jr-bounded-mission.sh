#!/data/data/com.termux/files/usr/bin/bash
set +e

BASE="$HOME/ED-GITHUB-COMPARE"
RUNTIME="$BASE/Runtime/ED"
REPORT_DIR="$BASE/Reports"
mkdir -p "$REPORT_DIR" || exit 2
REPORT="$REPORT_DIR/ED-JR-BOUNDED-MISSION-$(date +%Y%m%d-%H%M%S).log"

PROMPT='ED JR BOUNDED SELF-IMPROVEMENT MISSION — READ ONLY.
Use only information available in your retrieved memory/context and this prompt. Do not claim you inspected files, ran tools, or changed anything unless that actually happened.
Return no more than 200 words using exactly these headings:

1. CURRENT GOAL
2. ONE SAFE NEXT IMPROVEMENT
3. FILES THAT A HUMAN SHOULD INSPECT
4. VALIDATION TEST
5. ROLLBACK PLAN
   Choose one small, reversible improvement to ED runtime reliability. Do not edit files, run commands, restart services, or request broad permissions. If evidence is insufficient, say what specific evidence is missing.'

{
echo "===== ED JR BOUNDED MISSION — READ ONLY ====="
date
echo "REPORT=$REPORT"
echo "SAFETY=No project files changed; no services restarted."
echo

if [ ! -x "$RUNTIME" ]; then
echo "RESULT=STOPPED_RUNTIME_MISSING_OR_NOT_EXECUTABLE"
elif ! command -v timeout >/dev/null 2>&1; then
echo "RESULT=STOPPED_TIMEOUT_COMMAND_UNAVAILABLE"
else
echo "[1/2] Run one read-only mission (75-second limit)"
timeout 75s "$RUNTIME" ask "$PROMPT"
ED_EXIT=$?
echo
echo "ED_MISSION_EXIT=$ED_EXIT"
case "$ED_EXIT" in
0)   echo "MISSION_RESULT=RESPONSE_RECEIVED" ;;
124) echo "MISSION_RESULT=TIMEOUT" ;;
*)   echo "MISSION_RESULT=FAILED_OR_EMPTY_CHECK_OUTPUT" ;;
esac
fi

echo
echo "===== END MISSION REPORT ====="
} 2>&1 | tee "$REPORT"

Best-effort clipboard copy and verification.

CLIP_SET=UNAVAILABLE
CLIP_VERIFY=UNAVAILABLE

if command -v termux-clipboard-set >/dev/null 2>&1; then
if timeout 8s termux-clipboard-set < "$REPORT" >/dev/null 2>&1; then
CLIP_SET=PASS
else
CLIP_SET=FAILED_OR_TIMEOUT
fi
fi

if command -v termux-clipboard-get >/dev/null 2>&1; then
if timeout 8s termux-clipboard-get 2>/dev/null |
grep -Fq "ED JR BOUNDED MISSION"; then
CLIP_VERIFY=PASS
else
CLIP_VERIFY=NOT_CONFIRMED
fi
fi

{
echo "CLIPBOARD_COPY_FIRST_PASS=$CLIP_SET"
echo "CLIPBOARD_VERIFY_FIRST_PASS=$CLIP_VERIFY"
} >> "$REPORT"

CLIP_FINAL=UNAVAILABLE
if command -v termux-clipboard-set >/dev/null 2>&1; then
if timeout 8s termux-clipboard-set < "$REPORT" >/dev/null 2>&1; then
CLIP_FINAL=PASS
else
CLIP_FINAL=FAILED_OR_TIMEOUT
fi
fi

echo "REPORT_PATH=$REPORT"
echo "CLIPBOARD_COPY_FINAL_REPORT=$CLIP_FINAL"
echo "SAFETY=No project files changed; no services restarted."
