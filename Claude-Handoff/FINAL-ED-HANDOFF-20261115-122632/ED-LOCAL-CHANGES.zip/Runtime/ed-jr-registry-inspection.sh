#!/data/data/com.termux/files/usr/bin/bash
set +e

BASE="$HOME/ED-GITHUB-COMPARE"
REGISTRY="/storage/emulated/0/ED/Memory/Retrieval/RETRIEVAL_REGISTRY.md"
REPORT_DIR="$BASE/Reports"
mkdir -p "$REPORT_DIR" || exit 2
REPORT="$REPORT_DIR/ED-JR-REGISTRY-REVIEW-$(date +%Y%m%d-%H%M%S).log"
RUNTIME="$BASE/Runtime/ED"

{
echo "===== ED JR REGISTRY REVIEW — READ ONLY ====="
date
echo "REPORT=$REPORT"
echo "REGISTRY=$REGISTRY"
echo "SAFETY=Read-only inspection; no project files modified; no services restarted."
echo

if [ ! -x "$RUNTIME" ]; then
echo "RESULT=STOPPED_ED_RUNTIME_MISSING_OR_NOT_EXECUTABLE"
elif [ ! -r "$REGISTRY" ] || [ ! -f "$REGISTRY" ]; then
echo "RESULT=STOPPED_REGISTRY_MISSING_OR_UNREADABLE"
ls -ld "$REGISTRY" 2>&1
elif ! command -v timeout >/dev/null 2>&1; then
echo "RESULT=STOPPED_TIMEOUT_COMMAND_UNAVAILABLE"
else
echo "[1/3] Read registry (maximum 12000 bytes)"
REGISTRY_CONTENT="$(timeout 8s head -c 12000 "$REGISTRY" 2>&1)"
READ_EXIT=$?
echo "REGISTRY_READ_EXIT=$READ_EXIT"

if [ "$READ_EXIT" -ne 0 ] || [ -z "$REGISTRY_CONTENT" ]; then
  echo "RESULT=STOPPED_REGISTRY_READ_FAILED_OR_EMPTY"
else
  echo "REGISTRY_BYTES_SHOWN=${#REGISTRY_CONTENT}"
  echo "----- REGISTRY CONTENT START -----"
  printf '%s\n' "$REGISTRY_CONTENT"
  echo "----- REGISTRY CONTENT END -----"
  echo
  echo "[2/3] Ask Jr to review supplied evidence (60-second limit)"

  PROMPT="ED JR EVIDENCE-BASED REVIEW — READ ONLY.

You have been given the current contents of RETRIEVAL_REGISTRY.md below. Do not claim to inspect any other file or execute any tool. Do not edit files or restart services.
Use these exact headings and stay under 180 words:

1. OBSERVED FACTS — cite exact headings or short phrases from the supplied text.
2. UNCERTAINTIES — what the supplied text cannot establish.
3. ONE MINIMAL IMPROVEMENT — proposal only, not applied.
4. VALIDATION — a specific read-only test.
5. ROLLBACK — what to restore if a future approved change fails.
   If the supplied registry does not support a useful change, say so explicitly.

REGISTRY CONTENT FOLLOWS:
$REGISTRY_CONTENT"

  timeout 60s "$RUNTIME" ask "$PROMPT"
  ASK_EXIT=$?
  echo
  echo "ED_REVIEW_EXIT=$ASK_EXIT"
  case "$ASK_EXIT" in
    0)   echo "REVIEW_RESULT=RESPONSE_RECEIVED" ;;
    124) echo "REVIEW_RESULT=TIMEOUT" ;;
    *)   echo "REVIEW_RESULT=FAILED_OR_EMPTY_CHECK_OUTPUT" ;;
  esac
fi

fi
echo
echo "===== END REVIEW REPORT ====="
} 2>&1 | tee "$REPORT"

CLIP_COPY=UNAVAILABLE
CLIP_VERIFY=UNAVAILABLE

if command -v termux-clipboard-set >/dev/null 2>&1; then
if timeout 8s termux-clipboard-set < "$REPORT" >/dev/null 2>&1; then
CLIP_COPY=PASS
else
CLIP_COPY=FAILED_OR_TIMEOUT
fi
fi

if command -v termux-clipboard-get >/dev/null 2>&1; then
if timeout 8s termux-clipboard-get 2>/dev/null |
grep -Fq "ED JR REGISTRY REVIEW"; then
CLIP_VERIFY=PASS
else
CLIP_VERIFY=NOT_CONFIRMED
fi
fi

printf '\nCLIPBOARD_COPY=%s\nCLIPBOARD_VERIFY=%s\nFINAL_REPORT_PATH=%s\n' 
"$CLIP_COPY" "$CLIP_VERIFY" "$REPORT" | tee -a "$REPORT"

if command -v termux-clipboard-set >/dev/null 2>&1; then
if timeout 8s termux-clipboard-set < "$REPORT" >/dev/null 2>&1; then
echo "CLIPBOARD_COPY_FINAL_REPORT=PASS"
else
echo "CLIPBOARD_COPY_FINAL_REPORT=FAILED_OR_TIMEOUT"
fi
else
echo "CLIPBOARD_COPY_FINAL_REPORT=UNAVAILABLE"
fi
