#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

PROJECT = Path(os.environ.get(
    "ED_PROJECT_ROOT",
    str(Path.home() / "ED-GITHUB-COMPARE")
)).expanduser().resolve()

BACKUPS = Path.home() / "ED-JUNIOR-EXECUTION-BACKUPS"
REPORTS = Path.home() / "ED-JUNIOR-EXECUTOR-REPORTS"
MAX_BYTES = 2 * 1024 * 1024
BLOCKED = {
    ".git", "node_modules", ".env", ".ssh", "Backups",
    "backups", "ED Inventory", "ED-Core"
}
ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,80}$")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe_target(relative, root):
    if not isinstance(relative, str) or not relative:
        raise ValueError("Invalid relative path")

    p = Path(relative)
    if p.is_absolute() or any(
        part in ("", ".", "..") for part in p.parts
    ):
        raise ValueError("Invalid relative path")

    if any(
        part in BLOCKED or part.startswith(".env")
        for part in p.parts
    ):
        raise ValueError("Protected path")

    root_path = Path(root).resolve(strict=True)
    candidate = root_path

    # Reject symlinks BEFORE resolving any component.
    for index, part in enumerate(p.parts):
        candidate = candidate / part

        if candidate.is_symlink():
            raise ValueError("Symlink path component rejected")

        if not candidate.exists():
            raise ValueError("Target path does not exist")

        if index < len(p.parts) - 1 and not candidate.is_dir():
            raise ValueError("Parent path component is not a directory")

    if not candidate.is_file():
        raise ValueError("Target must be an existing regular file")

    target = candidate.resolve(strict=True)

    try:
        relative_target = target.relative_to(root_path)
    except ValueError:
        raise ValueError("Path escapes project root")

    if any(
        part in BLOCKED or part.startswith(".env")
        for part in relative_target.parts
    ):
        raise ValueError("Resolved destination is protected")

    if target.is_symlink() or not target.is_file():
        raise ValueError("Resolved target is not a regular file")

    return target

def syntax_check(path, data):
    suffix = path.suffix.lower()
    text = data.decode("utf-8")
    if suffix == ".sh":
        result = subprocess.run(
            ["bash", "-n"], input=text, text=True,
            capture_output=True, timeout=15
        )
        if result.returncode:
            raise ValueError("bash -n failed: " + result.stderr.strip()[:1200])
    elif suffix == ".py":
        compile(text, str(path), "exec")
    elif suffix == ".json":
        json.loads(text)
    return "CHECKED" if suffix in (".sh", ".py", ".json") else "NOT_AVAILABLE_FOR_FILE_TYPE"


def load_proposal(file, root):
    proposal = json.loads(Path(file).read_text(encoding="utf-8"))
    if not isinstance(proposal, dict):
        raise ValueError("Proposal must be a JSON object")
    task_id = proposal.get("id", "")
    if not isinstance(task_id, str) or not ID_RE.fullmatch(task_id):
        raise ValueError("Invalid proposal id")
    if proposal.get("operation") != "replace_file":
        raise ValueError("Only replace_file is supported")
    if not isinstance(proposal.get("task"), str) or not proposal["task"].strip():
        raise ValueError("Missing task description")
    if not isinstance(proposal.get("content"), str):
        raise ValueError("content must be a UTF-8 string")
    new_data = proposal["content"].encode("utf-8")
    if len(new_data) > MAX_BYTES or b"\x00" in new_data:
        raise ValueError("Content too large or binary content detected")
    target = safe_target(proposal.get("path", ""), root)
    old_data = target.read_bytes()
    if len(old_data) > MAX_BYTES or b"\x00" in old_data:
        raise ValueError("Existing target is too large or binary")
    expected = proposal.get("expected_sha256", "")
    if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise ValueError("Invalid expected_sha256")
    if sha(old_data) != expected:
        raise ValueError("SOURCE HASH MISMATCH: target changed since proposal")
    return proposal, target, old_data, new_data


def atomic_write(target, data, mode):
    fd, name = tempfile.mkstemp(prefix=".ed-junior-", dir=str(target.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(name, mode)
        os.replace(name, target)
    except Exception:
        try:
            os.unlink(name)
        except OSError:
            pass
        raise


def validate(file, root):
    p, target, old, new = load_proposal(file, root)
    check = syntax_check(target, new)
    return (
        "STATUS: APPROVAL_REQUIRED\n"
        f"ID: {p['id']}\nPATH: {p['path']}\n"
        f"OLD_SHA256: {sha(old)}\nNEW_SHA256: {sha(new)}\n"
        f"SYNTAX_CHECK: {check}\n"
        "PROJECT_CHANGED: NO\n"
        "BACKUP_CREATED: NO\n"
        "NEXT: Review proposal, then explicitly run apply with --approve ID."
    )


def apply(file, approval, root):
    p, target, old, new = load_proposal(file, root)
    if approval != p["id"]:
        raise ValueError("Approval ID does not match proposal ID")
    check = syntax_check(target, new)
    task_dir = BACKUPS / p["id"]
    if task_dir.exists():
        raise ValueError("Backup/task ID already exists; refusing to overwrite")
    backup_file = task_dir / "original"
    task_dir.mkdir(parents=True)
    try:
        shutil.copy2(target, backup_file)
        if backup_file.read_bytes() != old:
            raise ValueError("Backup verification failed")
        manifest = {
            "id": p["id"], "path": p["path"],
            "original_sha256": sha(old), "applied_sha256": sha(new),
            "backup": str(backup_file),
            "created_utc": datetime.now(timezone.utc).isoformat()
        }
        atomic_write(target, new, target.stat().st_mode)
        if target.read_bytes() != new:
            raise ValueError("Post-write hash verification failed")
        try:
            syntax_check(target, new)
        except Exception:
            if sha(target.read_bytes()) == sha(new):
                atomic_write(target, old, backup_file.stat().st_mode)
            raise
        (task_dir / "manifest.json").write_text(
            json.dumps(manifest, indent=2), encoding="utf-8"
        )
        return (
            "STATUS: VERIFIED\n"
            f"ID: {p['id']}\nPATH: {p['path']}\n"
            f"SYNTAX_CHECK: {check}\n"
            f"APPLIED_SHA256: {sha(new)}\n"
            f"BACKUP: {backup_file}\n"
            "PROJECT_CHANGE: APPLIED_AND_HASH_VERIFIED\n"
            "ROLLBACK: AVAILABLE_IF_TARGET_HASH_IS_UNCHANGED"
        )
    except Exception:
        if target.exists() and sha(target.read_bytes()) == sha(new):
            atomic_write(target, old, backup_file.stat().st_mode)
        raise


def rollback(task_id, root):
    if not ID_RE.fullmatch(task_id):
        raise ValueError("Invalid task ID")
    task_dir = BACKUPS / task_id
    manifest_file = task_dir / "manifest.json"
    if not manifest_file.is_file():
        raise ValueError("Verified task manifest not found")
    m = json.loads(manifest_file.read_text(encoding="utf-8"))
    target = safe_target(m["path"], root)
    current = target.read_bytes()
    if sha(current) != m["applied_sha256"]:
        raise ValueError("ROLLBACK BLOCKED: target changed after this task")
    backup = Path(m["backup"])
    original = backup.read_bytes()
    if sha(original) != m["original_sha256"]:
        raise ValueError("Backup hash mismatch")
    atomic_write(target, original, backup.stat().st_mode)
    if sha(target.read_bytes()) != m["original_sha256"]:
        raise ValueError("Rollback verification failed")
    return (
        "STATUS: ROLLED_BACK\n"
        f"ID: {task_id}\nPATH: {m['path']}\n"
        f"RESTORED_SHA256: {sha(original)}\n"
        "ROLLBACK_VERIFICATION: PASS"
    )


def self_test():
    with tempfile.TemporaryDirectory(prefix="ed-junior-test-") as temp:
        root = Path(temp).resolve()
        (root / "Runtime").mkdir()
        target = root / "Runtime" / "sample.txt"
        target.write_text("original\n", encoding="utf-8")
        original = target.read_bytes()
        proposal = {
            "id": "SELFTEST-001",
            "task": "Replace sandbox sample content",
            "operation": "replace_file",
            "path": "Runtime/sample.txt",
            "expected_sha256": sha(original),
            "content": "updated by isolated self-test\n"
        }
        proposal_file = root / "proposal.json"
        proposal_file.write_text(json.dumps(proposal), encoding="utf-8")
        old_backup_root = globals()["BACKUPS"]
        globals()["BACKUPS"] = root / "backups"
        try:
            v = validate(proposal_file, root)
            if "APPROVAL_REQUIRED" not in v or target.read_bytes() != original:
                raise ValueError("Dry-run test failed")
            a = apply(proposal_file, "SELFTEST-001", root)
            if "STATUS: VERIFIED" not in a:
                raise ValueError("Apply test failed")
            r = rollback("SELFTEST-001", root)
            if "STATUS: ROLLED_BACK" not in r or target.read_bytes() != original:
                raise ValueError("Rollback test failed")
        finally:
            globals()["BACKUPS"] = old_backup_root
    return (
        "ED JUNIOR EXECUTOR SELF-TEST\n"
        "STATUS: PASS\n"
        "Dry-run: PASS\nApply: PASS\nHash verification: PASS\n"
        "Backup verification: PASS\nRollback: PASS\n"
        "Sandbox only: YES\nProject files changed: NO"
    )


def emit(report):
    print(report, flush=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    report_file = REPORTS / (
        "report-" + datetime.now().strftime("%Y%m%d-%H%M%S") + ".txt"
    )
    report_file.write_text(report + "\n", encoding="utf-8")
    print("REPORT_FILE:", report_file, flush=True)
    setter = shutil.which("termux-clipboard-set")
    getter = shutil.which("termux-clipboard-get")
    if setter and getter:
        try:
            subprocess.run([setter], input=report.encode(), check=True, timeout=10)
            copied = subprocess.run(
                [getter], capture_output=True, check=True, timeout=10
            ).stdout
            if copied == report.encode():
                print("CLIPBOARD: PASS (byte-verified)", flush=True)
            else:
                print("CLIPBOARD: FAIL (content mismatch)", flush=True)
        except Exception as exc:
            print("CLIPBOARD: FAIL (" + str(exc)[:160] + ")", flush=True)
    else:
        print("CLIPBOARD: UNAVAILABLE (Termux:API commands not found)", flush=True)


def main():
    parser = argparse.ArgumentParser(
        description="Bounded local ED Junior file-change executor"
    )
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("self-test")
    v = sub.add_parser("validate")
    v.add_argument("proposal")
    a = sub.add_parser("apply")
    a.add_argument("proposal")
    a.add_argument("--approve", required=True)
    r = sub.add_parser("rollback")
    r.add_argument("task_id")
    args = parser.parse_args()
    root = PROJECT
    if not root.is_dir():
        raise ValueError("Project root does not exist: " + str(root))
    if args.command == "self-test":
        report = self_test()
    elif args.command == "validate":
        report = validate(args.proposal, root)
    elif args.command == "apply":
        report = apply(args.proposal, args.approve, root)
    else:
        report = rollback(args.task_id, root)
    emit(report)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        emit("STATUS: FAILED\nREASON: " + str(exc))
        sys.exit(1)
