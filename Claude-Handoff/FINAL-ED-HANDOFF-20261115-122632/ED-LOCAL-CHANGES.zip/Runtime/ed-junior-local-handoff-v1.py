#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import urllib.request
from datetime import datetime
from pathlib import Path

ROOT = (Path.home() / "ED-GITHUB-COMPARE").resolve()
EXECUTOR = ROOT / "Runtime" / "ed-junior-executor-v1.py"
OLLAMA = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/")
MODEL = os.environ.get("ED_LOCAL_MODEL", "llama3.2:3b")
OUT = Path.home() / "ED-JUNIOR-PROPOSALS"
MAX_SOURCE = 48 * 1024
BLOCKED = {".git", "node_modules", ".env", ".ssh", "Backups",
           "backups", "ED Inventory", "ED-Core"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def resolve_target(relative):
    p = Path(relative)
    if p.is_absolute() or not relative or any(x in ("", ".", "..") for x in p.parts):
        raise ValueError("Target must be a safe project-relative path")
    if any(x in BLOCKED or x.startswith(".env") for x in p.parts):
        raise ValueError("Protected target path")
    target = (ROOT / p).resolve()
    if not target.is_relative_to(ROOT):
        raise ValueError("Target escapes project root")
    if not target.is_file() or target.is_symlink():
        raise ValueError("Target must be an existing regular file")
    data = target.read_bytes()
    if len(data) > MAX_SOURCE or b"\x00" in data:
        raise ValueError("Target too large or binary; maximum is 48 KiB")
    try:
        source = data.decode("utf-8")
    except UnicodeDecodeError:
        raise ValueError("Target is not UTF-8 text")
    return target, data, source


def build_prompt(task, relative, source, source_hash, proposal_id):
    return f"""You are ED Junior, a local software development agent.
Return ONLY one valid JSON object. No Markdown fences or commentary.

Return exactly these two keys:
{{
  "task": "short description",
  "content": "the complete replacement file as a JSON string"
}}

Rules:
- Make only the requested change.
- Preserve unrelated behavior and existing functionality.
- Do not return id, operation, path, or expected_sha256.
- Those four fields are assigned and verified by the trusted generator.
- Do not return a diff. Return the complete replacement file in content.
- Do not invent test results or claim the change was applied.
- If you cannot safely complete the task, return the unchanged original content and explain the limitation in task.
- Do not include shell commands or instructions to execute commands.

USER TASK:
{task}

TARGET FILE:
{relative}

CURRENT FILE CONTENT:
{source}
"""



def request_model(prompt):
    payload = json.dumps({
        "model": MODEL,
        "prompt": prompt,
        "stream": False,
        "format": "json",
        "options": {"temperature": 0.1, "num_predict": 8192}
    }).encode()
    req = urllib.request.Request(
        OLLAMA + "/api/generate",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=600) as response:
        response_bytes = response.read()

    # Preserve the exact Ollama HTTP response before parsing it.
    raw_dir = Path.home() / "ED-JUNIOR-RAW-RESPONSES"
    raw_dir.mkdir(parents=True, exist_ok=True)
    raw_file = raw_dir / (
        "ollama-" + datetime.now().strftime("%Y%m%d-%H%M%S-%f") + ".json"
    )
    raw_file.write_bytes(response_bytes)
    print("RAW_RESPONSE_FILE:", raw_file, flush=True)
    print("RAW_RESPONSE_BYTES:", len(response_bytes), flush=True)

    result = json.loads(response_bytes.decode("utf-8"))
    for key in ("done", "done_reason", "prompt_eval_count",
                "eval_count", "total_duration"):
        if key in result:
            print("OLLAMA_" + key.upper() + ":", result[key], flush=True)

    text = result.get("response")
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Local model returned no proposal text")
    return text


def validate_proposal(raw, proposal_id, relative, source_hash):
    obj = json.loads(raw)
    if not isinstance(obj, dict):
        raise ValueError("Model response is not a JSON object")

    required_model_keys = {"task", "content"}
    if set(obj.keys()) != required_model_keys:
        raise ValueError(
            "Model response must contain exactly task and content; "
            "trusted metadata is generator-controlled"
        )

    if not isinstance(obj.get("task"), str) or not obj["task"].strip():
        raise ValueError("Proposal task description missing")

    if not isinstance(obj.get("content"), str):
        raise ValueError("Proposal content missing or not text")

    # Runtime/ED and .sh targets are shell scripts even when
    # their filenames have no extension. Reject fragments early.
    is_shell = relative == "Runtime/ED" or relative.endswith(".sh")
    content_bytes = obj["content"].encode("utf-8")

    if is_shell:
        if len(content_bytes) < 200:
            raise ValueError(
                "Shell proposal rejected: replacement is suspiciously short "
                f"({len(content_bytes)} bytes; minimum 200)"
            )
        check = subprocess.run(
            ["bash", "-n"],
            input=obj["content"],
            capture_output=True,
            text=True,
            timeout=30
        )
        if check.returncode != 0:
            raise ValueError(
                "Shell proposal rejected by bash -n:\n" +
                (check.stderr or check.stdout)
            )

    if len(content_bytes) > 2 * 1024 * 1024:
        raise ValueError("Proposed replacement exceeds executor limit")

    # Construct executor metadata locally. Never trust model-supplied values.
    return {
        "id": proposal_id,
        "task": obj["task"],
        "operation": "replace_file",
        "path": relative,
        "expected_sha256": source_hash,
        "content": obj["content"]
    }



def offline_test():
    model_response = {
        "task": "test",
        "content": "print('test')\n"
    }
    raw = json.dumps(model_response)
    got = validate_proposal(
        raw, "TEST-001", "Runtime/test.py", "a" * 64
    )

    expected = {
        "id": "TEST-001",
        "task": "test",
        "operation": "replace_file",
        "path": "Runtime/test.py",
        "expected_sha256": "a" * 64,
        "content": "print('test')\n"
    }

    if got != expected:
        raise ValueError("Trusted metadata construction test failed")

    # Model attempts to override trusted metadata must be rejected.
    malicious = dict(model_response)
    malicious["id"] = "MODEL-OVERRIDE"
    try:
        validate_proposal(
            json.dumps(malicious),
            "TEST-001", "Runtime/test.py", "a" * 64
        )
    except ValueError:
        pass
    else:
        raise ValueError("Model metadata override was not rejected")

    # Original six-field executor proposal shape must remain intact.
    if set(got) != {
        "id", "task", "operation", "path",
        "expected_sha256", "content"
    }:
        raise ValueError("Executor proposal schema changed")

    return (
        "ED JUNIOR LOCAL HANDOFF SELF-TEST\n"
        "STATUS: PASS\n"
        "Two-field model response: PASS\n"
        "Trusted metadata construction: PASS\n"
        "Metadata override rejection: PASS\n"
        "Executor schema compatibility: PASS\n"
        "Network used: NO\n"
        "Project files changed: NO"
    )



def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--task")
    parser.add_argument("--file")
    args = parser.parse_args()

    if args.self_test:
        print(offline_test())
        return
    if not args.task or not args.file:
        raise ValueError("Usage: --task 'work to do' --file Runtime/file.py")
    if not EXECUTOR.is_file():
        raise ValueError("Executor not found: " + str(EXECUTOR))

    target, old_data, source = resolve_target(args.file)
    source_hash = digest(old_data)
    proposal_id = "EDJ-" + datetime.now().strftime("%Y%m%d%H%M%S")
    prompt = build_prompt(args.task, args.file, source, source_hash, proposal_id)

    print("JUNIOR: contacting local Ollama only", flush=True)
    print("MODEL:", MODEL, flush=True)
    raw = request_model(prompt)
    proposal = validate_proposal(raw, proposal_id, args.file, source_hash)

    OUT.mkdir(parents=True, exist_ok=True)
    proposal_file = OUT / (proposal_id + ".json")
    with proposal_file.open("x", encoding="utf-8") as f:
        json.dump(proposal, f, ensure_ascii=False, indent=2)
        f.write("\n")

    check = subprocess.run(
        [sys.executable, str(EXECUTOR), "validate", str(proposal_file)],
        capture_output=True, text=True, timeout=60
    )
    if check.returncode != 0:
        proposal_file.unlink(missing_ok=True)
        raise ValueError("Executor rejected proposal:\n" + check.stdout + check.stderr)

    print("STATUS: PROPOSAL_READY")
    print("ID:", proposal_id)
    print("TARGET:", args.file)
    print("SOURCE_SHA256:", source_hash)
    print("PROPOSAL:", proposal_file)
    print(check.stdout.strip())
    print("PROJECT_CHANGE: NONE")
    print("APPROVAL: REQUIRED")
    print("NEXT: Inspect proposal JSON before approving its exact ID.")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("STATUS: FAILED")
        print("REASON:", str(exc)[:1800])
        sys.exit(1)
