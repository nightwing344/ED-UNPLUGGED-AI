#!/data/data/com.termux/files/usr/bin/bash
set +e
BASE="$HOME/ED-GITHUB-COMPARE"
REPORT_DIR="$BASE/Reports"
mkdir -p "$REPORT_DIR" || exit 2
REPORT="$REPORT_DIR/ED-OLLAMA-HTTP-$(date +%Y%m%d-%H%M%S).log"

{
echo '===== ED OLLAMA HTTP CHECK ====='
date
echo "REPORT=$REPORT"
echo 'SAFETY=Read-only HTTP GET; no source files changed; no services restarted.'
echo

if ! command -v curl >/dev/null 2>&1; then
echo 'OLLAMA_HTTP_CHECK=CURL_UNAVAILABLE'
else
echo '[1/2] Check local Ollama endpoint (5-second limit)'
CURL_OUTPUT="$(curl -sS --max-time 5 -o /dev/null -w 'HTTP=%{http_code} TIME=%{time_total}s' 'http://127.0.0.1:11434/api/tags' 2>&1)"
CURL_EXIT=$?
printf '%s\n' "$CURL_OUTPUT"
echo "CURL_EXIT=$CURL_EXIT"

if [ "$CURL_EXIT" -eq 0 ]; then
  case "$CURL_OUTPUT" in
    *HTTP=200*) echo 'OLLAMA_HTTP_CHECK=PASS' ;;
    *) echo 'OLLAMA_HTTP_CHECK=NON_200_OR_UNEXPECTED_OUTPUT' ;;
  esac
else
  echo 'OLLAMA_HTTP_CHECK=FAILED_OR_UNREACHABLE'
fi

fi

echo
echo '===== END ====='
} 2>&1 | tee "$REPORT"

CLIP_COPY=UNAVAILABLE
CLIP_VERIFY=UNAVAILABLE
if command -v termux-clipboard-set >/dev/null 2>&1; then
if timeout 8s termux-clipboard-set < "$REPORT" >/dev/null 2>&1; then
CLIP_COPY=PASS
else
CLIP_COPY=FAILED_OR_TIMEOUT
fi
fi
if command -v termux-clipboard-get >/dev/null 2>&1; then
if timeout 8s termux-clipboard-get 2>/dev/null | grep -Fq 'ED OLLAMA HTTP CHECK'; then
CLIP_VERIFY=PASS
else
CLIP_VERIFY=NOT_CONFIRMED
fi
fi

printf '\nCLIPBOARD_COPY_FIRST_PASS=%s\nCLIPBOARD_VERIFY_FIRST_PASS=%s\n' "$CLIP_COPY" "$CLIP_VERIFY" >> "$REPORT"

if command -v termux-clipboard-set >/dev/null 2>&1 && timeout 8s termux-clipboard-set < "$REPORT" >/dev/null 2>&1; then
CLIP_FINAL=PASS
else
CLIP_FINAL=FAILED_OR_UNAVAILABLE
fi
echo "REPORT_PATH=$REPORT"
echo "CLIPBOARD_COPY_FINAL_REPORT=$CLIP_FINAL"
