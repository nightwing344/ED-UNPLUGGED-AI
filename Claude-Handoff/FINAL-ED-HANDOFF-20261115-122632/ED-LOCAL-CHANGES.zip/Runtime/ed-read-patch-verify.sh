#!/data/data/com.termux/files/usr/bin/bash
set +e

BASE="$HOME/ED-GITHUB-COMPARE"
ASK="$BASE/Runtime/ed-ask-v1.sh"
REPORT_DIR="$BASE/Reports"
mkdir -p "$REPORT_DIR" || exit 2
STAMP="$(date +%Y%m%d-%H%M%S)"
REPORT="$REPORT_DIR/ED-ASK-READ-PATCH-VERIFY-$STAMP.log"
BACKUP="$ASK.pre-timeout-patch-$STAMP"

{
echo '===== ED ASK READ / PATCH / VERIFY ====='
date
echo "TARGET=$ASK"
echo "REPORT=$REPORT"
echo 'No inference test; no service restart.'
echo

if [ ! -f "$ASK" ] || [ ! -w "$ASK" ]; then
echo 'RESULT=STOPPED_TARGET_MISSING_OR_NOT_WRITABLE'
exit 10
fi

echo '===== READ: CURRENT REQUEST CODE ====='
sed -n '180,255p' "$ASK"

echo
echo '===== BACKUP BEFORE PATCH ====='
if ! cp -p "$ASK" "$BACKUP"; then
echo 'RESULT=STOPPED_BACKUP_FAILED'
exit 11
fi
echo "BACKUP=$BACKUP"
sha256sum "$ASK" "$BACKUP"

echo
echo '===== PATCH DEFAULT TIMEOUT 120 -> 300 ====='
python - "$ASK" <<'PY_PATCH'
import pathlib, sys
p = pathlib.Path(sys.argv[1])
s = p.read_text()
old = 'os.environ.get("ED_INFERENCE_TIMEOUT_SECONDS", "120")'
new = 'os.environ.get("ED_INFERENCE_TIMEOUT_SECONDS", "300")'
count = s.count(old)
if count != 1:
print(f"PATCH_ABORTED: expected one exact match, found {count}")
raise SystemExit(3)
p.write_text(s.replace(old, new, 1))
print("PATCH_APPLIED: default timeout is now 300 seconds")
PY_PATCH
PATCH_RC=$?
if [ "$PATCH_RC" -ne 0 ]; then
cp -p "$BACKUP" "$ASK"
echo 'RESULT=PATCH_ABORTED_BACKUP_RESTORED'
exit 12
fi

echo
echo '===== VERIFY PATCH ====='
if ! grep -Fq 'os.environ.get("ED_INFERENCE_TIMEOUT_SECONDS", "300")' "$ASK"; then
echo 'VERIFY_FAIL=TIMEOUT_SETTING'
cp -p "$BACKUP" "$ASK"
echo 'ROLLBACK=RESTORED'
exit 13
fi

if ! bash -n "$ASK"; then
echo 'VERIFY_FAIL=BASH_SYNTAX'
cp -p "$BACKUP" "$ASK"
echo 'ROLLBACK=RESTORED'
exit 14
fi

echo 'BASH_SYNTAX=PASS'
echo 'DEFAULT_TIMEOUT_SECONDS=300'
echo 'ENVIRONMENT_OVERRIDE=SUPPORTED'
echo
echo '===== FINAL REQUEST CODE ====='
sed -n '210,245p' "$ASK"
echo
echo '===== CHANGE DIFF ====='
diff -u "$BACKUP" "$ASK"
DIFF_RC=$?
if [ "$DIFF_RC" -ne 1 ]; then
echo "VERIFY_FAIL=UNEXPECTED_DIFF_EXIT_$DIFF_RC"
cp -p "$BACKUP" "$ASK"
echo 'ROLLBACK=RESTORED'
exit 15
fi

echo 'DIFF_VERIFY=PASS'
echo 'RESULT=PATCHED_AND_VERIFIED'
} 2>&1 | tee "$REPORT"

RUN_RC=${PIPESTATUS[0]}

CLIP_COPY=UNAVAILABLE
CLIP_VERIFY=UNAVAILABLE
if command -v termux-clipboard-set >/dev/null 2>&1; then
if timeout 8s termux-clipboard-set < "$REPORT" >/dev/null 2>&1; then
CLIP_COPY=PASS
else
CLIP_COPY=FAILED
fi
fi
if command -v termux-clipboard-get >/dev/null 2>&1; then
if timeout 8s termux-clipboard-get 2>/dev/null | grep -Fq 'ED ASK READ / PATCH / VERIFY'; then
CLIP_VERIFY=PASS
else
CLIP_VERIFY=NOT_CONFIRMED
fi
fi

printf '\nSCRIPT_EXIT=%s\nCLIPBOARD_COPY=%s\nCLIPBOARD_VERIFY=%s\n' "$RUN_RC" "$CLIP_COPY" "$CLIP_VERIFY" >> "$REPORT"

if command -v termux-clipboard-set >/dev/null 2>&1 && timeout 8s termux-clipboard-set < "$REPORT" >/dev/null 2>&1; then
CLIP_FINAL=PASS
else
CLIP_FINAL=FAILED_OR_UNAVAILABLE
fi

echo "REPORT_PATH=$REPORT"
echo "SCRIPT_EXIT=$RUN_RC"
echo "CLIPBOARD_COPY_FINAL_REPORT=$CLIP_FINAL"
exit "$RUN_RC"
