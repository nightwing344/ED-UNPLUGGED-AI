#!/data/data/com.termux/files/usr/bin/bash
set +e

ROOT="$HOME/ED-GITHUB-COMPARE"
WEB="$ROOT/Interface/Web"
REPORTS="$ROOT/Reports"
TS="$(date +%Y%m%d-%H%M%S)"
REPORT="$REPORTS/ED-PHASE57-bundle-runtime-identity-$TS.log"
SERVER_LOG="$REPORTS/ED-PHASE57-isolated-$TS.log"

mkdir -p "$REPORTS"

exec > >(tee "$REPORT") 2>&1

echo "===== ED PHASE 57 — BUNDLE/RUNTIME IDENTITY DIAGNOSTIC ====="
date
echo "REPORT=$REPORT"

cleanup() {
  if [ -n "${TEST_PID:-}" ] && kill -0 "$TEST_PID" 2>/dev/null; then
    echo "[CLEANUP] Stopping ONLY isolated Phase 57 process PID=$TEST_PID"
    kill "$TEST_PID" 2>/dev/null
    sleep 1
    kill -0 "$TEST_PID" 2>/dev/null && kill -9 "$TEST_PID" 2>/dev/null
  fi
}
trap cleanup EXIT

cd "$WEB" || exit 1

echo
echo "[10%] Verify source patch exists"
SOURCE_MATCHES="$(grep -c 'MAX_WHATIF_WORDS' server.ts 2>/dev/null)"
echo "SOURCE_MATCHES=$SOURCE_MATCHES"

echo
echo "[20%] Inspect built bundle"
BUNDLE="$WEB/dist/server.cjs"

if [ -f "$BUNDLE" ]; then
  echo "BUNDLE_PRESENT=YES"
  echo "BUNDLE_SIZE=$(wc -c < "$BUNDLE")"
  echo "BUNDLE_MTIME=$(stat -c '%y' "$BUNDLE" 2>/dev/null)"
else
  echo "BUNDLE_PRESENT=NO"
fi

echo
echo "[30%] Search bundle for Phase 56 limiter"
BUNDLE_MATCHES="$(grep -c 'MAX_WHATIF_WORDS' "$BUNDLE" 2>/dev/null)"
echo "BUNDLE_LIMITER_MATCHES=$BUNDLE_MATCHES"

if [ "$BUNDLE_MATCHES" -gt 0 ] 2>/dev/null; then
  echo "BUNDLE_LIMITER=FOUND"
  grep -n -A12 -B5 'MAX_WHATIF_WORDS' "$BUNDLE" | head -40
else
  echo "BUNDLE_LIMITER=NOT_FOUND"
fi

echo
echo "[40%] Identify bundle hash"
if [ -f "$BUNDLE" ]; then
  sha256sum "$BUNDLE"
fi

echo
echo "[50%] Verify port 3101 is unused"
if command -v curl >/dev/null 2>&1; then
  BEFORE_HTTP="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 2 http://127.0.0.1:3101/ 2>/dev/null)"
else
  BEFORE_HTTP="curl-unavailable"
fi
echo "PORT_3101_BEFORE_HTTP=$BEFORE_HTTP"

echo
echo "[60%] Start isolated server explicitly from dist/server.cjs"

if [ "$BEFORE_HTTP" != "000" ] && [ "$BEFORE_HTTP" != "curl-unavailable" ]; then
  echo "ERROR=Port 3101 is already occupied; refusing to start anything."
  echo "RESULT=DIAGNOSTIC BLOCKED"
  exit 2
fi

PORT=3101 \
ED_RUNTIME_TIMEOUT_MS=180000 \
node "$BUNDLE" >"$SERVER_LOG" 2>&1 &
TEST_PID=$!

echo "ISOLATED_PID=$TEST_PID"
echo "SERVER_LOG=$SERVER_LOG"

READY=NO
for i in $(seq 1 30); do
  HTTP="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 2 http://127.0.0.1:3101/ 2>/dev/null)"
  if [ "$HTTP" != "000" ]; then
    READY=YES
    echo "ISOLATED_HTTP=$HTTP"
    break
  fi
  sleep 1
done

echo "ISOLATED_READY=$READY"

if [ "$READY" != "YES" ]; then
  echo "ERROR=Isolated server did not become ready"
  echo "--- SERVER LOG ---"
  cat "$SERVER_LOG"
  echo "RESULT=DIAGNOSTIC FAILED"
  exit 3
fi

echo
echo "[70%] Verify running process command line"
echo "PROCESS_CMDLINE:"
tr '\0' ' ' < "/proc/$TEST_PID/cmdline" 2>/dev/null
echo
echo "PROCESS_CWD:"
readlink "/proc/$TEST_PID/cwd" 2>/dev/null

echo
echo "[80%] Verify runtime endpoint behavior"

RESPONSE="$REPORTS/ED-PHASE57-response-$TS.json"

curl -sS \
  --max-time 210 \
  -X POST \
  -H 'Content-Type: application/json' \
  -d '{"prompt":"What if a city planted 100 trees? Answer in no more than 80 words. Give exactly two likely effects and one uncertainty.","premiseCategory":"technological","depth":"deep"}' \
  "http://127.0.0.1:3101/api/ed/whatif" \
  > "$RESPONSE"

CURL_EXIT=$?
echo "WHATIF_CURL_EXIT=$CURL_EXIT"
echo "RESPONSE_FILE=$RESPONSE"

echo "--- RESPONSE ---"
cat "$RESPONSE"
echo

echo
echo "[90%] Count returned words and compare source/bundle identity"

python - "$RESPONSE" "$BUNDLE" <<'PY'
import json
import re
import sys

response_file = sys.argv[1]
bundle_file = sys.argv[2]

try:
    with open(response_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    text = data.get("rawAnalysis", "")
    words = re.findall(r"\S+", text)

    print(f"RETURNED_WORDS={len(words)}")
    print("MAX_ALLOWED=80")

    if len(words) <= 80:
        print("WORD_LIMIT_RESULT=PASS")
    else:
        print("WORD_LIMIT_RESULT=FAIL")

except Exception as e:
    print(f"JSON_PARSE_ERROR={e}")

try:
    with open(bundle_file, "r", encoding="utf-8", errors="ignore") as f:
        bundle = f.read()

    if "MAX_WHATIF_WORDS" in bundle:
        print("BUNDLE_CONTAINS_LIMITER=YES")
    else:
        print("BUNDLE_CONTAINS_LIMITER=NO")

    if "analysisWords.slice(0, MAX_WHATIF_WORDS)" in bundle:
        print("BUNDLE_CONTAINS_SLICE=YES")
    else:
        print("BUNDLE_CONTAINS_SLICE=NO")

except Exception as e:
    print(f"BUNDLE_READ_ERROR={e}")
PY

echo
echo "[95%] Inspect isolated server log"
cat "$SERVER_LOG"

echo
echo "[98%] Verify live port 3000 remains untouched"
LIVE_HTTP="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:3000/ 2>/dev/null)"
echo "LIVE_PORT_3000_HTTP=$LIVE_HTTP"

echo
echo "[100%] Final diagnostic classification"

if grep -q 'BUNDLE_CONTAINS_LIMITER=YES' "$REPORT" &&
   grep -q 'BUNDLE_CONTAINS_SLICE=YES' "$REPORT" &&
   grep -q 'WORD_LIMIT_RESULT=FAIL' "$REPORT"; then
  echo "RESULT=RUNTIME PATH MISMATCH OR ROUTE DUPLICATION"
  echo "NEXT=Inspect route registration / loaded bundle path before any repair."
elif grep -q 'BUNDLE_CONTAINS_LIMITER=NO' "$REPORT"; then
  echo "RESULT=BUILD OUTPUT DOES NOT CONTAIN SOURCE PATCH"
  echo "NEXT=Diagnose build output/path before modifying source."
elif grep -q 'WORD_LIMIT_RESULT=PASS' "$REPORT"; then
  echo "RESULT=PHASE56 REPAIR VERIFIED"
  echo "NEXT=Live server still intentionally untouched."
else
  echo "RESULT=UNRESOLVED DIAGNOSTIC"
fi

echo
echo "REPORT=$REPORT"
echo "RESPONSE_FILE=$RESPONSE"

# Best-effort clipboard copy.
if command -v termux-clipboard-set >/dev/null 2>&1; then
  cat "$REPORT" | termux-clipboard-set
  echo "CLIPBOARD_COPY=ATTEMPTED"
else
  echo "CLIPBOARD_COPY=UNAVAILABLE"
fi
