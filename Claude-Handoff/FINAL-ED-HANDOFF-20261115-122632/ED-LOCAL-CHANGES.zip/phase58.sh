#!/data/data/com.termux/files/usr/bin/bash
set +e

ROOT="$HOME/ED-GITHUB-COMPARE"
WEB="$ROOT/Interface/Web"
REPORTS="$ROOT/Reports"
TS="$(date +%Y%m%d-%H%M%S)"
REPORT="$REPORTS/ED-PHASE58-whatif-route-forensics-$TS.log"

mkdir -p "$REPORTS"
exec > >(tee "$REPORT") 2>&1

echo "===== ED PHASE 58 — WHAT-IF ROUTE FORENSICS ====="
date
echo "REPORT=$REPORT"

cd "$WEB" || exit 1

echo
echo "[10%] Verify project"
echo "WEB=$WEB"
echo "SERVER_TS=$(stat -c '%y' server.ts 2>/dev/null)"
echo "BUNDLE_TS=$(stat -c '%y' dist/server.cjs 2>/dev/null)"

echo
echo "[20%] Count What-if route registrations in source"
SOURCE_ROUTE_COUNT="$(grep -nF "app.post('/api/ed/whatif'" server.ts | wc -l)"
echo "SOURCE_ROUTE_COUNT=$SOURCE_ROUTE_COUNT"

echo
echo "[30%] Show ALL What-if references in source"
grep -n -E "/api/ed/whatif|whatif|What-If|What-if" server.ts | head -120

echo
echo "[40%] Show route context around every exact What-if registration"

python - <<'PY'
from pathlib import Path

p = Path("server.ts")
lines = p.read_text(errors="replace").splitlines()

matches = [
    i for i, line in enumerate(lines)
    if "/api/ed/whatif" in line
]

print(f"EXACT_SOURCE_ROUTE_MATCHES={len(matches)}")

for n, i in enumerate(matches, 1):
    start = max(0, i - 12)
    end = min(len(lines), i + 55)

    print()
    print("=" * 70)
    print(f"ROUTE_MATCH_{n}=server.ts:{i+1}")
    print("=" * 70)

    for j in range(start, end):
        print(f"{j+1:5}: {lines[j]}")
PY

echo
echo "[55%] Count compiled What-if route registrations"
BUNDLE_ROUTE_COUNT="$(grep -oF "/api/ed/whatif" dist/server.cjs | wc -l)"
echo "BUNDLE_ROUTE_REFERENCE_COUNT=$BUNDLE_ROUTE_COUNT"

echo
echo "[60%] Show compiled route context"
python - <<'PY'
from pathlib import Path

p = Path("dist/server.cjs")
text = p.read_text(errors="replace")

needle = "/api/ed/whatif"
positions = []
start = 0

while True:
    i = text.find(needle, start)
    if i < 0:
        break
    positions.append(i)
    start = i + len(needle)

print(f"EXACT_BUNDLE_ROUTE_REFERENCES={len(positions)}")

for n, pos in enumerate(positions, 1):
    print()
    print("=" * 70)
    print(f"BUNDLE_MATCH_{n}=byte:{pos}")
    print("=" * 70)
    print(text[max(0, pos-1000):pos+2500])
PY

echo
echo "[70%] Locate response-writing paths near What-if code"
python - <<'PY'
from pathlib import Path
text = Path("dist/server.cjs").read_text(errors="replace")

needle = "/api/ed/whatif"
positions = []
start = 0

while True:
    i = text.find(needle, start)
    if i < 0:
        break
    positions.append(i)
    start = i + len(needle)

for n, pos in enumerate(positions, 1):
    section = text[max(0, pos-3000):pos+7000]

    print()
    print("=" * 70)
    print(f"RESPONSE_PATH_SCAN_{n}")
    print("=" * 70)

    for term in [
        "res.json({",
        "rawAnalysis:",
        "result.text",
        "MAX_WHATIF_WORDS",
        "analysisWords",
        "limitedAnalysis",
        "res.status("
    ]:
        print(f"{term}: {section.count(term)}")
PY

echo
echo "[80%] Search for middleware/proxy mechanisms that could affect routing"
grep -n -E \
  "app\.use|router\.use|express\(|createProxy|proxy|http-proxy|rewrite|forward|/api/ed" \
  server.ts | head -220

echo
echo "[88%] Check source ordering around route registration"
grep -n -E \
  "app\.(use|post|get|all)|router\.(use|post|get|all)" \
  server.ts | head -260

echo
echo "[94%] Verify source and bundle hashes"
echo "SERVER_SOURCE_SHA256:"
sha256sum server.ts

echo "BUNDLE_SHA256:"
sha256sum dist/server.cjs

echo
echo "[97%] Verify live server remains untouched"
LIVE_HTTP="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:3000/ 2>/dev/null)"
echo "LIVE_PORT_3000_HTTP=$LIVE_HTTP"

echo
echo "[100%] Classification"

if [ "$SOURCE_ROUTE_COUNT" = "1" ] && [ "$BUNDLE_ROUTE_REFERENCE_COUNT" -ge 1 ]; then
  echo "RESULT=SOURCE_HAS_SINGLE_WHATIF_ROUTE"
  echo "NEXT=Use compiled route context to identify why limiter is bypassed."
elif [ "$SOURCE_ROUTE_COUNT" -gt 1 ]; then
  echo "RESULT=DUPLICATE_SOURCE_WHATIF_ROUTE"
  echo "NEXT=Target duplicate registration only after review."
else
  echo "RESULT=UNRESOLVED_ROUTE_STRUCTURE"
fi

echo
echo "REPORT=$REPORT"

if command -v termux-clipboard-set >/dev/null 2>&1; then
  cat "$REPORT" | termux-clipboard-set
  echo "CLIPBOARD_COPY=ATTEMPTED"
else
  echo "CLIPBOARD_COPY=UNAVAILABLE"
fi
