#!/data/data/com.termux/files/usr/bin/bash
set +e

ROOT="$HOME/ED-GITHUB-COMPARE"
WEB="$ROOT/Interface/Web"
REPORTS="$ROOT/Reports"
TS="$(date +%Y%m%d-%H%M%S)"
REPORT="$REPORTS/ED-PHASE59-regex-wordlimit-$TS.log"
SERVER_LOG="$REPORTS/ED-PHASE59-isolated-$TS.log"
RESPONSE="$REPORTS/ED-PHASE59-response-$TS.json"

mkdir -p "$REPORTS"
exec > >(tee "$REPORT") 2>&1

echo "===== ED PHASE 59 — WORD-LIMITER REGEX REPAIR ====="
date
echo "REPORT=$REPORT"

TEST_PID=""
cleanup() {
  if [ -n "$TEST_PID" ] && kill -0 "$TEST_PID" 2>/dev/null; then
    echo "[CLEANUP] Stop only Phase 59 isolated process PID=$TEST_PID"
    kill "$TEST_PID" 2>/dev/null
    sleep 1
    if kill -0 "$TEST_PID" 2>/dev/null; then
      kill -9 "$TEST_PID" 2>/dev/null
    fi
  fi
}
trap cleanup EXIT

cd "$WEB" || exit 1

echo
echo "[10%] Verify exact malformed expression"
python - <<'PY'
from pathlib import Path
s = Path("server.ts").read_text()
bad = r"rawAnalysis.split(/\\s+/)"
good = r"rawAnalysis.split(/\s+/)"
print("MALFORMED_MATCHES=" + str(s.count(bad)))
print("CORRECT_EXPRESSION_ALREADY_PRESENT=" + str(s.count(good)))
PY

BAD_COUNT="$(python -c 'from pathlib import Path; print(Path("server.ts").read_text().count(r"rawAnalysis.split(/\\s+/)"))')"

if [ "$BAD_COUNT" != "1" ]; then
  echo "STOP=Expected exactly one malformed expression; source unchanged."
  echo "RESULT=SAFE STOP"
  exit 2
fi

echo
echo "[20%] Back up source and compiled server BEFORE editing"
SOURCE_BACKUP="$WEB/server.ts.phase59-backup-$TS"
BUNDLE_BACKUP="$WEB/dist/server.cjs.phase59-backup-$TS"

cp -p server.ts "$SOURCE_BACKUP" || exit 3
cp -p dist/server.cjs "$BUNDLE_BACKUP" || exit 3

echo "SOURCE_BACKUP=$SOURCE_BACKUP"
echo "BUNDLE_BACKUP=$BUNDLE_BACKUP"
sha256sum "$SOURCE_BACKUP" "$BUNDLE_BACKUP"

echo
echo "[30%] Correct only the extra backslash"
python - <<'PY'
from pathlib import Path

p = Path("server.ts")
s = p.read_text()
bad = r"rawAnalysis.split(/\\s+/)"
good = r"rawAnalysis.split(/\s+/)"

if s.count(bad) != 1:
    raise SystemExit("STOP: malformed target count changed")

p.write_text(s.replace(bad, good, 1))
print("PATCH_APPLIED=YES")
print("CORRECT_EXPRESSION_MATCHES=" + str(p.read_text().count(good)))
print("MALFORMED_EXPRESSION_MATCHES=" + str(p.read_text().count(bad)))
PY

if [ "$?" -ne 0 ]; then
  cp -p "$SOURCE_BACKUP" server.ts
  echo "RESULT=PATCH FAILED; SOURCE RESTORED"
  exit 4
fi

echo
echo "[40%] Build and verify compiled regex"
npm run build
BUILD_EXIT=$?
echo "BUILD_EXIT=$BUILD_EXIT"

if [ "$BUILD_EXIT" -ne 0 ]; then
  cp -p "$SOURCE_BACKUP" server.ts
  cp -p "$BUNDLE_BACKUP" dist/server.cjs
  echo "RESULT=BUILD FAILED; SOURCE AND SERVER BUNDLE RESTORED"
  exit 5
fi

python - <<'PY'
from pathlib import Path
s = Path("dist/server.cjs").read_text(errors="replace")
good = r"rawAnalysis.split(/\s+/)"
bad = r"rawAnalysis.split(/\\s+/)"
print("BUNDLE_CORRECT_REGEX=" + str(s.count(good)))
print("BUNDLE_MALFORMED_REGEX=" + str(s.count(bad)))
print("BUNDLE_LIMITER_PRESENT=" + str("MAX_WHATIF_WORDS" in s))
if s.count(good) < 1 or "MAX_WHATIF_WORDS" not in s:
    raise SystemExit("Compiled bundle verification failed")
PY

if [ "$?" -ne 0 ]; then
  cp -p "$SOURCE_BACKUP" server.ts
  cp -p "$BUNDLE_BACKUP" dist/server.cjs
  echo "RESULT=BUNDLE CHECK FAILED; SOURCE AND SERVER BUNDLE RESTORED"
  exit 6
fi

echo
echo "[50%] Confirm port 3101 is free"
if command -v ss >/dev/null 2>&1 && ss -ltn 2>/dev/null | grep -qE '[:.]3101[[:space:]]'; then
  echo "STOP=Port 3101 already has a listener; no process will be killed."
  echo "RESULT=TEST BLOCKED; BACKUPS RETAINED"
  exit 7
fi

HTTP_BEFORE="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 2 http://127.0.0.1:3101/ 2>/dev/null)"
echo "PORT_3101_HTTP_BEFORE=$HTTP_BEFORE"
if [ "$HTTP_BEFORE" != "000" ]; then
  echo "STOP=Port 3101 is responding; refusing to start another server."
  echo "RESULT=TEST BLOCKED; BACKUPS RETAINED"
  exit 8
fi

echo
echo "[60%] Start isolated rebuilt bundle"
PORT=3101 ED_RUNTIME_TIMEOUT_MS=180000 node "$WEB/dist/server.cjs" >"$SERVER_LOG" 2>&1 &
TEST_PID=$!
echo "ISOLATED_PID=$TEST_PID"
echo "SERVER_LOG=$SERVER_LOG"

READY=NO
for i in $(seq 1 30); do
  H="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 2 http://127.0.0.1:3101/ 2>/dev/null)"
  if [ "$H" != "000" ]; then
    READY=YES
    echo "ISOLATED_HTTP=$H"
    break
  fi
  sleep 1
done

if [ "$READY" != "YES" ]; then
  echo "ERROR=Isolated server failed to start"
  cat "$SERVER_LOG"
  echo "RESULT=TEST FAILED; BACKUPS RETAINED"
  exit 9
fi

echo
echo "[70%] Test What-if endpoint"
curl -sS --max-time 210 \
  -X POST \
  -H 'Content-Type: application/json' \
  -d '{"prompt":"What if a city planted 100 trees? Answer in no more than 80 words. Give exactly two likely effects and one uncertainty.","premiseCategory":"technological","depth":"deep"}' \
  http://127.0.0.1:3101/api/ed/whatif > "$RESPONSE"

CURL_EXIT=$?
echo "CURL_EXIT=$CURL_EXIT"
echo "RESPONSE_FILE=$RESPONSE"
echo "--- RESPONSE ---"
cat "$RESPONSE"
echo

echo
echo "[80%] Programmatically verify the hard word limit"
python - "$RESPONSE" <<'PY'
import json, re, sys
try:
    with open(sys.argv[1], encoding="utf-8") as f:
        data = json.load(f)
    text = data.get("rawAnalysis", "")
    words = re.findall(r"\S+", text)
    count = len(words)
    print(f"RETURNED_WORDS={count}")
    print("MAX_ALLOWED=80")
    print("WORD_LIMIT_PASS=" + str(count <= 80))
    print("RESPONSE_PRESENT=" + str(bool(text)))
    if count > 80 or not text:
        raise SystemExit(1)
except Exception as e:
    print("VERIFICATION_ERROR=" + str(e))
    raise SystemExit(1)
PY

VERIFY_EXIT=$?
echo "VERIFY_EXIT=$VERIFY_EXIT"

echo
echo "[90%] Inspect isolated server log"
cat "$SERVER_LOG"

echo
echo "[95%] Confirm live port 3000 remains responsive"
LIVE_HTTP="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:3000/ 2>/dev/null)"
echo "LIVE_PORT_3000_HTTP=$LIVE_HTTP"

echo
echo "[100%] Final status"
if [ "$VERIFY_EXIT" -eq 0 ] && [ "$LIVE_HTTP" = "200" ]; then
  echo "RESULT=PHASE59 REPAIR VERIFIED IN ISOLATED SERVER"
  echo "NOTE=Live port 3000 still uses its existing running process."
else
  echo "RESULT=VERIFICATION FAILED; BACKUPS RETAINED FOR REVIEW"
fi

echo "SOURCE_BACKUP=$SOURCE_BACKUP"
echo "BUNDLE_BACKUP=$BUNDLE_BACKUP"
echo "REPORT=$REPORT"
echo "RESPONSE_FILE=$RESPONSE"

if command -v termux-clipboard-set >/dev/null 2>&1; then
  cat "$REPORT" | termux-clipboard-set
  echo "CLIPBOARD_COPY=ATTEMPTED"
else
  echo "CLIPBOARD_COPY=UNAVAILABLE"
fi
