#!/data/data/com.termux/files/usr/bin/bash
set +e

ROOT="$HOME/ED-GITHUB-COMPARE"
WEB="$ROOT/Interface/Web"
REPORTS="$ROOT/Reports"
TS="$(date +%Y%m%d-%H%M%S)"
REPORT="$REPORTS/ED-PHASE60-live-update-$TS.log"
SERVER_LOG="$REPORTS/ED-PHASE60-live-server-$TS.log"
RESPONSE="$REPORTS/ED-PHASE60-live-whatif-$TS.json"

mkdir -p "$REPORTS"
exec > >(tee "$REPORT") 2>&1

echo "===== ED PHASE 60 — SAFETY-GATED LIVE UPDATE ====="
date
echo "REPORT=$REPORT"

cd "$WEB" || exit 1

echo
echo "[10%] Verify corrected source and built bundle"
python - <<'PY'
from pathlib import Path
source = Path("server.ts").read_text()
bundle = Path("dist/server.cjs").read_text(errors="replace")
good = r"rawAnalysis.split(/\s+/)"
bad = r"rawAnalysis.split(/\\s+/)"
checks = {
    "SOURCE_CORRECT_REGEX": source.count(good) == 1,
    "SOURCE_BAD_REGEX_ABSENT": source.count(bad) == 0,
    "BUNDLE_CORRECT_REGEX": bundle.count(good) == 1,
    "BUNDLE_BAD_REGEX_ABSENT": bundle.count(bad) == 0,
    "BUNDLE_LIMITER_PRESENT": "MAX_WHATIF_WORDS" in bundle,
}
for k, v in checks.items():
    print(f"{k}={'PASS' if v else 'FAIL'}")
if not all(checks.values()):
    raise SystemExit("Preflight failed; live server will not be touched.")
PY
if [ "$?" -ne 0 ]; then
  echo "RESULT=SAFE STOP — corrected bundle not verified"
  exit 2
fi

echo
echo "[20%] Create fresh live-update backups"
SOURCE_BACKUP="$WEB/server.ts.phase60-backup-$TS"
BUNDLE_BACKUP="$WEB/dist/server.cjs.phase60-backup-$TS"
cp -p server.ts "$SOURCE_BACKUP" || exit 3
cp -p dist/server.cjs "$BUNDLE_BACKUP" || exit 3
echo "SOURCE_BACKUP=$SOURCE_BACKUP"
echo "BUNDLE_BACKUP=$BUNDLE_BACKUP"
sha256sum "$SOURCE_BACKUP" "$BUNDLE_BACKUP"

echo
echo "[30%] Capture current live health"
ROOT_HTTP="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:3000/ 2>/dev/null)"
HEALTH_HTTP="$(curl -sS -o "$REPORTS/ED-PHASE60-before-health-$TS.json" -w '%{http_code}' --max-time 3 http://127.0.0.1:3000/api/health 2>/dev/null)"
echo "LIVE_ROOT_HTTP=$ROOT_HTTP"
echo "LIVE_HEALTH_HTTP=$HEALTH_HTTP"

if [ "$ROOT_HTTP" != "200" ]; then
  echo "RESULT=SAFE STOP — live server was not healthy before update"
  exit 4
fi

echo
echo "[40%] Identify port 3000 owner and launch safety"
python - "$WEB" "$SERVER_LOG" <<'PY'
import os, sys, glob, signal, time, subprocess, json
from pathlib import Path

web = str(Path(sys.argv[1]).resolve())
log_path = sys.argv[2]
port_hex = format(3000, "04X")
inodes = set()

for table in ("/proc/net/tcp", "/proc/net/tcp6"):
    try:
        lines = Path(table).read_text().splitlines()[1:]
    except Exception:
        continue
    for line in lines:
        f = line.split()
        if len(f) > 9 and f[1].rsplit(":", 1)[-1].upper() == port_hex and f[3] == "0A":
            inodes.add(f[9])

owners = set()
for proc in glob.glob("/proc/[0-9]*"):
    pid = int(proc.rsplit("/", 1)[-1])
    try:
        for fd in glob.glob(proc + "/fd/*"):
            try:
                target = os.readlink(fd)
            except Exception:
                continue
            if target.startswith("socket:[") and target[8:-1] in inodes:
                owners.add(pid)
                break
    except Exception:
        pass

print("PORT3000_SOCKET_INODES=" + ",".join(sorted(inodes)))
print("PORT3000_OWNER_PIDS=" + ",".join(map(str, sorted(owners))))

if len(owners) != 1:
    print("RESTART_AUTHORIZED=NO")
    print("REASON=Port owner missing or ambiguous; no process stopped.")
    raise SystemExit(20)

pid = next(iter(owners))
proc = f"/proc/{pid}"

try:
    argv = Path(proc + "/cmdline").read_bytes().decode(errors="replace").split("\0")
    argv = [x for x in argv if x]
    cwd = os.path.realpath(proc + "/cwd")
    exe = os.path.realpath(proc + "/exe")
    stat = Path(proc + "/stat").read_text().split()
    ppid = int(stat[3])
    parent_cmd = Path(f"/proc/{ppid}/cmdline").read_bytes().decode(errors="replace").replace("\0", " ").strip()
    env_raw = Path(proc + "/environ").read_bytes().split(b"\0")
    env = {}
    for item in env_raw:
        if b"=" in item:
            k, v = item.split(b"=", 1)
            env[k.decode(errors="replace")] = v.decode(errors="replace")
except Exception as e:
    print("RESTART_AUTHORIZED=NO")
    print("REASON=Could not inspect process safely: " + str(e))
    raise SystemExit(21)

print("LIVE_PID=" + str(pid))
print("LIVE_CWD=" + cwd)
print("LIVE_EXECUTABLE=" + exe)
print("LIVE_ARGV=" + repr(argv))
print("LIVE_PARENT_PID=" + str(ppid))
print("LIVE_PARENT_COMMAND=" + parent_cmd)

cmdline = " ".join(argv)
if cwd != web or not any(a == web + "/dist/server.cjs" or a == "dist/server.cjs" for a in argv):
    print("RESTART_AUTHORIZED=NO")
    print("REASON=Live process is not confidently identified as this project's dist/server.cjs.")
    raise SystemExit(22)

if any(word in parent_cmd.lower() for word in
       ("pm2", "supervisord", "termux-services", "runit", "openclaw", "forever", "monit", "systemd")):
    print("RESTART_AUTHORIZED=NO")
    print("REASON=A possible process manager/supervisor was detected.")
    raise SystemExit(23)

if ppid == 1:
    print("RESTART_AUTHORIZED=NO")
    print("REASON=Parent is PID 1; launch manager cannot be established confidently.")
    raise SystemExit(24)

print("RESTART_AUTHORIZED=YES")
print("ACTION=Graceful restart of the verified project server only.")

# Preserve exact arguments, working directory, and environment without printing secrets.
try:
    os.kill(pid, signal.SIGTERM)
except Exception as e:
    print("RESTART_AUTHORIZED=NO")
    print("REASON=Could not send graceful stop: " + str(e))
    raise SystemExit(25)

for _ in range(100):
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        break
    except PermissionError:
        print("REASON=Cannot confirm old process exit; refusing forced termination.")
        raise SystemExit(26)
    time.sleep(0.1)
else:
    print("REASON=Old process did not exit gracefully; refusing SIGKILL.")
    raise SystemExit(27)

# Reuse the original environment/arguments; only redirect output to a fresh log.
try:
    with open(log_path, "ab", buffering=0) as out:
        child = subprocess.Popen(
            argv,
            executable=exe,
            cwd=web,
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=out,
            stderr=subprocess.STDOUT,
            start_new_session=True,
            close_fds=True,
        )
    print("NEW_LIVE_PID=" + str(child.pid))
    print("LIVE_LOG=" + log_path)
    Path(os.path.join(web, ".phase60-new-live-pid")).write_text(str(child.pid))
except Exception as e:
    print("RESTART_LAUNCH_FAILED=" + str(e))
    print("RECOVERY=Backups retained; inspect report and log before any further action.")
    raise SystemExit(28)
PY
IDENTITY_EXIT=$?
echo "IDENTITY_RESTART_EXIT=$IDENTITY_EXIT"

if [ "$IDENTITY_EXIT" -ne 0 ]; then
  echo "RESULT=SAFE STOP — live process not restarted"
  echo "Backups retained; review owner/parent details above."
  echo "REPORT=$REPORT"
  if command -v termux-clipboard-set >/dev/null 2>&1; then cat "$REPORT" | termux-clipboard-set; fi
  exit 5
fi

echo
echo "[55%] Wait for the restarted live server"
READY=NO
for i in $(seq 1 30); do
  H="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 2 http://127.0.0.1:3000/ 2>/dev/null)"
  if [ "$H" = "200" ]; then
    READY=YES
    echo "LIVE_ROOT_HTTP=$H"
    break
  fi
  sleep 1
done
echo "LIVE_READY=$READY"

if [ "$READY" != "YES" ]; then
  echo "RESULT=LIVE SERVER DID NOT RECOVER — do not kill other processes"
  echo "Inspect LIVE_LOG=$SERVER_LOG and backups."
  cat "$SERVER_LOG"
  exit 6
fi

echo
echo "[65%] Verify live health endpoint"
curl -sS --max-time 5 http://127.0.0.1:3000/api/health
echo
HEALTH_HTTP="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 5 http://127.0.0.1:3000/api/health 2>/dev/null)"
echo "LIVE_HEALTH_HTTP=$HEALTH_HTTP"

echo
echo "[75%] Test the actual live What-if endpoint"
curl -sS --max-time 210 \
  -X POST \
  -H 'Content-Type: application/json' \
  -d '{"prompt":"What if a city planted 100 trees? Answer in no more than 80 words. Give exactly two likely effects and one uncertainty.","premiseCategory":"technological","depth":"deep"}' \
  http://127.0.0.1:3000/api/ed/whatif > "$RESPONSE"
CURL_EXIT=$?
echo "WHATIF_CURL_EXIT=$CURL_EXIT"
echo "RESPONSE_FILE=$RESPONSE"
cat "$RESPONSE"
echo

echo
echo "[85%] Verify live response word count"
python - "$RESPONSE" <<'PY'
import json, re, sys
try:
    with open(sys.argv[1], encoding="utf-8") as f:
        data = json.load(f)
    value = data.get("rawAnalysis", "")
    count = len(re.findall(r"\S+", value))
    print(f"LIVE_RETURNED_WORDS={count}")
    print("MAX_ALLOWED=80")
    print("LIVE_WORD_LIMIT_PASS=" + str(bool(value) and count <= 80))
    if not value or count > 80:
        raise SystemExit(1)
except Exception as e:
    print("LIVE_VERIFICATION_ERROR=" + str(e))
    raise SystemExit(1)
PY
WORD_EXIT=$?

echo
echo "[95%] Check live server process and log"
PIDFILE="$WEB/.phase60-new-live-pid"
if [ -f "$PIDFILE" ]; then
  NEWPID="$(cat "$PIDFILE")"
  echo "NEW_LIVE_PID=$NEWPID"
  if kill -0 "$NEWPID" 2>/dev/null; then echo "NEW_PROCESS_ALIVE=YES"; else echo "NEW_PROCESS_ALIVE=NO"; fi
fi
echo "LIVE_LOG=$SERVER_LOG"
tail -60 "$SERVER_LOG" 2>/dev/null

echo
echo "[100%] Final status"
if [ "$WORD_EXIT" -eq 0 ] && [ "$HEALTH_HTTP" = "200" ]; then
  echo "RESULT=PHASE60 LIVE WORD-LIMIT REPAIR VERIFIED"
else
  echo "RESULT=LIVE UPDATE NEEDS REVIEW"
  echo "Backups retained; do not perform additional restarts blindly."
fi

echo "SOURCE_BACKUP=$SOURCE_BACKUP"
echo "BUNDLE_BACKUP=$BUNDLE_BACKUP"
echo "REPORT=$REPORT"
echo "RESPONSE_FILE=$RESPONSE"

if command -v termux-clipboard-set >/dev/null 2>&1; then
  cat "$REPORT" | termux-clipboard-set
  echo "CLIPBOARD_COPY=ATTEMPTED"
else
  echo "CLIPBOARD_COPY=UNAVAILABLE"
fi
