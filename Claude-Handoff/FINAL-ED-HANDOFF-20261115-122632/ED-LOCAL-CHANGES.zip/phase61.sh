#!/data/data/com.termux/files/usr/bin/bash
set +e

ROOT="$HOME/ED-GITHUB-COMPARE"
REPORTS="$ROOT/Reports"
TS="$(date +%Y%m%d-%H%M%S)"
REPORT="$REPORTS/ED-PHASE61-live-process-discovery-$TS.log"

mkdir -p "$REPORTS"
exec > >(tee "$REPORT") 2>&1

echo "===== ED PHASE 61 — READ-ONLY PROCESS DISCOVERY ====="
date
echo "REPORT=$REPORT"

echo
echo "[15%] Verify live server remains healthy"
echo "ROOT_HTTP=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:3000/ 2>/dev/null)"
echo "HEALTH_HTTP=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:3000/api/health 2>/dev/null)"

echo
echo "[30%] Available process and socket tools"
for tool in ps ss lsof fuser netstat; do
  if command -v "$tool" >/dev/null 2>&1; then
    echo "$tool=$(command -v "$tool")"
  else
    echo "$tool=unavailable"
  fi
done

echo
echo "[45%] Process table — Node, server, supervisor candidates"
ps -A -o PID,PPID,USER,STAT,NAME,ARGS 2>&1 | \
  grep -Ei '(^ *PID|node|server\.cjs|server\.ts|npm|pm2|termux-services|openclaw|supervis|vite|tsx|esbuild)' | \
  head -160

echo
echo "[60%] Inspect TCP listener tables without changing anything"
for f in /proc/net/tcp /proc/net/tcp6; do
  echo "--- $f ---"
  if [ -r "$f" ]; then
    awk 'NR==1 || toupper($2) ~ /:0BB8$/ {print}' "$f" 2>&1
  else
    echo "UNREADABLE"
  fi
done

echo
echo "[72%] Check socket utilities if available"
if command -v ss >/dev/null 2>&1; then
  ss -ltnp 2>&1 | grep -E 'Local Address|:3000|:3101' || true
fi
if command -v lsof >/dev/null 2>&1; then
  lsof -nP -iTCP:3000 -sTCP:LISTEN 2>&1
fi
if command -v fuser >/dev/null 2>&1; then
  fuser -v 3000/tcp 2>&1
fi
if command -v netstat >/dev/null 2>&1; then
  netstat -ltnp 2>&1 | grep -E 'Local Address|:3000|:3101' || true
fi

echo
echo "[85%] Inspect accessible process command lines"
for p in /proc/[0-9]*; do
  [ -r "$p/cmdline" ] || continue
  PID="${p##*/}"
  CMD="$(tr '\0' ' ' < "$p/cmdline" 2>/dev/null)"
  case "$CMD" in
    *server.cjs*|*server.ts*|*openclaw-gateway*|*npm*run*dev*|*vite*|*tsx*)
      PPID_VALUE="$(awk '{print $4}' "$p/stat" 2>/dev/null)"
      CWD="$(readlink "$p/cwd" 2>/dev/null)"
      echo "PID=$PID PPID=$PPID_VALUE CWD=$CWD"
      echo "CMD=$CMD"
      if [ -r "/proc/$PPID_VALUE/cmdline" ]; then
        echo "PARENT_CMD=$(tr '\0' ' ' < "/proc/$PPID_VALUE/cmdline" 2>/dev/null)"
      fi
      ;;
  esac
done

echo
echo "[95%] Confirm no changes were made"
echo "SOURCE_SHA256:"
sha256sum "$ROOT/Interface/Web/server.ts"
echo "BUNDLE_SHA256:"
sha256sum "$ROOT/Interface/Web/dist/server.cjs"
echo "LIVE_ROOT_HTTP=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:3000/ 2>/dev/null)"

echo
echo "[100%] Result"
echo "RESULT=READ-ONLY DISCOVERY COMPLETE"
echo "No process was stopped or restarted."
echo "REPORT=$REPORT"

if command -v termux-clipboard-set >/dev/null 2>&1; then
  cat "$REPORT" | termux-clipboard-set
  echo "CLIPBOARD_COPY=ATTEMPTED"
else
  echo "CLIPBOARD_COPY=UNAVAILABLE"
fi
