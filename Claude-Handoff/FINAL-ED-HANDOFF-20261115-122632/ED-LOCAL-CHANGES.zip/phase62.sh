#!/data/data/com.termux/files/usr/bin/bash
set +e

ROOT="$HOME/ED-GITHUB-COMPARE"
REPORTS="$ROOT/Reports"
TS="$(date +%Y%m%d-%H%M%S)"
REPORT="$REPORTS/ED-PHASE62-launch-context-$TS.log"
PID=20271

mkdir -p "$REPORTS"
exec > >(tee "$REPORT") 2>&1

echo "===== ED PHASE 62 — LAUNCH CONTEXT ====="
date
echo "REPORT=$REPORT"

echo
echo "[15%] Confirm process still exists"
if [ ! -d "/proc/$PID" ]; then
  echo "TARGET_PID=$PID NOT PRESENT"
else
  echo "TARGET_PID=$PID PRESENT"
  echo "--- status ---"
  grep -E '^(Name|State|Pid|PPid|Uid|Gid|NSpid|Threads):' "/proc/$PID/status" 2>&1
  echo "--- executable and working directory ---"
  readlink "/proc/$PID/exe" 2>&1
  readlink "/proc/$PID/cwd" 2>&1
  echo "--- command line ---"
  tr '\0' ' ' < "/proc/$PID/cmdline" 2>&1
  echo
  echo "--- selected non-secret environment fields ---"
  tr '\0' '\n' < "/proc/$PID/environ" 2>/dev/null |
    grep -E '^(PORT|NODE_ENV|PREFIX|HOME|TMPDIR|TERMUX_VERSION|INVOCATION_ID)=' |
    sed -E 's/^(HOME|TMPDIR)=.*/\1=[path redacted]/'
fi

echo
echo "[35%] Inspect PID 1 identity"
echo "PID1_STATUS:"
grep -E '^(Name|State|Pid|PPid|Uid|Gid):' /proc/1/status 2>&1
echo "PID1_EXE=$(readlink /proc/1/exe 2>&1)"
echo -n "PID1_CMD="
tr '\0' ' ' < /proc/1/cmdline 2>&1
echo

echo
echo "[50%] Inspect available service management"
echo "PREFIX=${PREFIX:-unknown}"
for path in \
  "$PREFIX/var/service" \
  "$PREFIX/var/service/openclaw" \
  "$PREFIX/var/service/ed" \
  "$HOME/.termux/boot" \
  "$HOME/.termux/tasker"
do
  if [ -e "$path" ]; then
    echo "PATH_PRESENT=$path"
    ls -ld "$path" 2>&1
    if [ -d "$path" ] && [ "$path" = "$PREFIX/var/service" ]; then
      find "$path" -maxdepth 2 -type l -print 2>&1 | head -60
    fi
  else
    echo "PATH_ABSENT=$path"
  fi
done

if command -v sv >/dev/null 2>&1; then
  echo "--- service status (read-only) ---"
  sv status "$PREFIX"/var/service/* 2>&1
fi

echo
echo "[70%] Inspect tmux session metadata"
if command -v tmux >/dev/null 2>&1; then
  tmux list-sessions 2>&1
  echo "--- tmux pane process metadata ---"
  tmux list-panes -a -F 'session=#{session_name} pane_pid=#{pane_pid} current=#{pane_current_command}' 2>&1
else
  echo "tmux=unavailable"
fi

echo
echo "[85%] Check launch scripts for references to the live server"
for dir in "$HOME/.termux/boot" "$PREFIX/var/service"; do
  [ -d "$dir" ] || continue
  grep -RIlE 'server\.cjs|ED-GITHUB-COMPARE|node .*dist/server' "$dir" 2>/dev/null |
    head -40 |
    while IFS= read -r f; do
      echo "LAUNCH_REFERENCE=$f"
      grep -nE 'server\.cjs|ED-GITHUB-COMPARE|node .*dist/server' "$f" 2>/dev/null | head -20
    done
done

echo
echo "[95%] Confirm live health"
echo "ROOT_HTTP=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:3000/ 2>/dev/null)"
echo "HEALTH_HTTP=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:3000/api/health 2>/dev/null)"

echo
echo "[100%] RESULT=READ-ONLY LAUNCH DISCOVERY COMPLETE"
echo "No files or processes were changed."
echo "REPORT=$REPORT"

if command -v termux-clipboard-set >/dev/null 2>&1; then
  termux-clipboard-set < "$REPORT" 2>/dev/null
  echo "CLIPBOARD_COPY=ATTEMPTED"
else
  echo "CLIPBOARD_COPY=UNAVAILABLE"
fi
