#!/data/data/com.termux/files/usr/bin/bash
set +e

ROOT="$HOME/ED-GITHUB-COMPARE"
REPORTS="$ROOT/Reports"
TS="$(date +%Y%m%d-%H%M%S)"
REPORT="$REPORTS/ED-PHASE63-startup-review-$TS.log"
exec > >(tee "$REPORT") 2>&1

echo "===== ED PHASE 63 — STARTUP CONTROL REVIEW ====="
date
echo "REPORT=$REPORT"

echo
echo "[20%] Inspect Termux boot entry"
BOOT="$HOME/.termux/boot/ed-web-start"
if [ -f "$BOOT" ]; then
  echo "BOOT_FILE=$BOOT"
  sed -n '1,220p' "$BOOT"
else
  echo "BOOT_FILE_NOT_FOUND=$BOOT"
fi

echo
echo "[40%] Inspect referenced startup script"
START="$ROOT/Runtime/ed-web-start.sh"
if [ -f "$START" ]; then
  echo "START_SCRIPT=$START"
  sed -n '1,260p' "$START"
else
  echo "START_SCRIPT_NOT_FOUND=$START"
fi

echo
echo "[60%] Search Runtime for launch and shutdown controls"
if [ -d "$ROOT/Runtime" ]; then
  find "$ROOT/Runtime" -maxdepth 2 -type f -print 2>/dev/null | head -100
  grep -RInE 'server\.cjs|3000|kill|pkill|start|stop|restart|PIDFILE|pidfile|nohup|setsid|termux-services' \
    "$ROOT/Runtime" "$HOME/.termux/boot" 2>/dev/null | head -180
fi

echo
echo "[75%] Inspect current server-related PID files"
find "$ROOT" -maxdepth 4 -type f \
  \( -iname '*server*.pid' -o -iname '*ed*.pid' -o -iname '*web*.pid' \) \
  -print 2>/dev/null | head -80

echo
echo "[90%] Confirm live server still responds"
echo "ROOT_HTTP=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:3000/ 2>/dev/null)"
echo "HEALTH_HTTP=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:3000/api/health 2>/dev/null)"

echo
echo "[100%] RESULT=READ-ONLY STARTUP REVIEW COMPLETE"
echo "No files or processes were changed."
echo "REPORT=$REPORT"

if command -v termux-clipboard-set >/dev/null 2>&1; then
  termux-clipboard-set < "$REPORT" 2>/dev/null
  echo "CLIPBOARD_COPY=ATTEMPTED"
else
  echo "CLIPBOARD_COPY=UNAVAILABLE"
fi
