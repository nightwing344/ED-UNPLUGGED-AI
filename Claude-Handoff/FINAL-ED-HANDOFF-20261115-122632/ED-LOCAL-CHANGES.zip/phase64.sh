#!/data/data/com.termux/files/usr/bin/bash
set +e

ROOT="$HOME/ED-GITHUB-COMPARE"
WEB="$ROOT/Interface/Web"
REPORTS="$ROOT/Reports"
STATE="$HOME/.ed/runtime"
PIDFILE="$STATE/web-server.pid"
START="$ROOT/Runtime/ed-web-start.sh"
EXPECTED_PID=20271
TS="$(date +%Y%m%d-%H%M%S)"
REPORT="$REPORTS/ED-PHASE64-controlled-restart-$TS.log"
mkdir -p "$REPORTS"
exec > >(tee "$REPORT") 2>&1

echo "===== ED PHASE 64 — CONTROLLED LIVE RESTART ====="
date
echo "REPORT=$REPORT"

health_code() {
  curl -sS -o /dev/null -w '%{http_code}' --max-time 3 \
    http://127.0.0.1:3000/api/health 2>/dev/null
}

echo
echo "[10%] Verify live service and startup files"
echo "LIVE_HEALTH_BEFORE=$(health_code)"
if [ "$(health_code)" != "200" ]; then
  echo "RESULT=SAFE STOP — live health is not 200"
  exit 0
fi
if [ ! -x "$START" ] || [ ! -f "$WEB/dist/server.cjs" ]; then
  echo "RESULT=SAFE STOP — launcher or bundle missing"
  exit 0
fi
if [ ! -r "$PIDFILE" ]; then
  echo "PIDFILE_MISSING=$PIDFILE"
  echo "RESULT=SAFE STOP — cannot verify launch identity"
  exit 0
fi

echo
echo "[25%] Verify PID file and exact process identity"
SAVED_PID="$(tr -cd '0-9' < "$PIDFILE")"
echo "PIDFILE_VALUE=$SAVED_PID"
if [ "$SAVED_PID" != "$EXPECTED_PID" ] || [ ! -d "/proc/$EXPECTED_PID" ]; then
  echo "RESULT=SAFE STOP — PID file does not identify expected live PID"
  exit 0
fi

EXE="$(readlink "/proc/$EXPECTED_PID/exe" 2>/dev/null)"
CWD="$(readlink "/proc/$EXPECTED_PID/cwd" 2>/dev/null)"
CMD="$(tr '\0' ' ' < "/proc/$EXPECTED_PID/cmdline" 2>/dev/null)"
echo "EXE=$EXE"
echo "CWD=$CWD"
echo "CMD=$CMD"

if [ "$EXE" != "$PREFIX/bin/node" ] ||
   [ "$CWD" != "$WEB" ] ||
   [ "$CMD" != "node dist/server.cjs " ] &&
   [ "$CMD" != "node dist/server.cjs" ]; then
  echo "RESULT=SAFE STOP — process identity mismatch"
  exit 0
fi

echo
echo "[40%] Back up current production bundle"
BACKUP="$WEB/dist/server.cjs.phase64-backup-$TS"
if ! cp -p "$WEB/dist/server.cjs" "$BACKUP"; then
  echo "RESULT=SAFE STOP — bundle backup failed"
  exit 0
fi
echo "BUNDLE_BACKUP=$BACKUP"
sha256sum "$WEB/dist/server.cjs" "$BACKUP"

echo
echo "[55%] Gracefully stop only the verified ED server"
kill -TERM "$EXPECTED_PID" 2>&1
if [ "$?" -ne 0 ]; then
  echo "RESULT=SAFE STOP — SIGTERM failed"
  exit 0
fi

STOPPED=NO
for i in $(seq 1 10); do
  if [ ! -d "/proc/$EXPECTED_PID" ]; then
    STOPPED=YES
    break
  fi
  sleep 1
done

if [ "$STOPPED" != YES ]; then
  echo "RESULT=SAFE STOP — process did not exit within 10 seconds"
  echo "No SIGKILL sent; no second server started."
  exit 0
fi
echo "OLD_PROCESS_EXITED=YES"

echo
echo "[70%] Relaunch through the existing ED startup script"
bash "$START"
START_EXIT=$?
echo "STARTUP_SCRIPT_EXIT=$START_EXIT"

echo
echo "[85%] Verify replacement process and live health"
NEW_PID="$(cat "$PIDFILE" 2>/dev/null)"
echo "NEW_PID=${NEW_PID:-missing}"
echo "LIVE_HEALTH_AFTER=$(health_code)"
echo "LIVE_ROOT_HTTP=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 3 http://127.0.0.1:3000/ 2>/dev/null)"

if [ "$START_EXIT" -eq 0 ] &&
   [ -n "$NEW_PID" ] &&
   [ "$NEW_PID" != "$EXPECTED_PID" ] &&
   [ -d "/proc/$NEW_PID" ] &&
   [ "$(health_code)" = "200" ]; then
  echo "RESULT=RESTARTED — health verified; word-limit test still required"
else
  echo "RESULT=RESTART NOT FULLY VERIFIED"
  echo "Backup retained at $BACKUP"
fi

echo
echo "[100%] REPORT=$REPORT"
if command -v termux-clipboard-set >/dev/null 2>&1; then
  termux-clipboard-set < "$REPORT" 2>/dev/null
  echo "CLIPBOARD_COPY=ATTEMPTED"
else
  echo "CLIPBOARD_COPY=UNAVAILABLE"
fi
